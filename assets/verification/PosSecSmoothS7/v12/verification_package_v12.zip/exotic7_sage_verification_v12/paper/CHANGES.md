# Source preservation and editorial observations

The authoritative input is the user's `v12_clean.tex`. `submitted.tex` and
`revised.tex` are both byte-identical copies of that file; the latter name is
retained solely for compatibility with the verification entry point. This
release does not alter the archived mathematical manuscript.

Two minor editorial issues are noted, not silently corrected:

- The acknowledgments say "specially ChatGPT" where "especially ChatGPT" is
  more idiomatic.
- An isolated "a" follows "calculations." in the acknowledgments.

The Code paragraph's claim of rigorous scalar interval checks is supported in
this release by an actual, separately labeled Sage RealIntervalField module.
Its precise intervals, precision, rational endpoints and limitations are in the
module output and the bilingual reports. It is not a rigorous interval scan of
all points and two-planes of the manifold.

The existence of public downloads is a deployment fact, not an algebraic
theorem. The publication record separately states what was actually uploaded
and what public URLs were tested.

Compared with the previous verification source, v12 has improved markings,
orientation and collar explanations, renamed shape slopes to mu_N and mu_S,
and revised its public code statement. These changes were reviewed against the
source afresh; a previous successful run was not accepted as a v12 result.
