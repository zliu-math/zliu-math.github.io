"""Export exact Sage polynomials as data for the independent Python checker."""


def polynomial(ring, value):
    p = ring(value)
    terms = []
    for powers, coefficient in sorted(p.dict().items()):
        if isinstance(powers, int):
            powers = (powers,)
        terms.append({"coefficient": str(coefficient),
                      "powers": [int(k) for k in powers]})
    return {"terms": terms}


def identity(identifier, ring, lhs, rhs):
    return {"kind": "polynomial_identity", "id": identifier,
            "variables": list(ring.variable_names()),
            "lhs": polynomial(ring, lhs), "rhs": polynomial(ring, rhs)}


def expression_identity(identifier, variables, lhs, rhs):
    """Keep arithmetic expressions unexpanded for an independent re-expansion."""
    return {"kind": "expression_identity", "id": identifier,
            "variables": list(variables), "lhs": lhs, "rhs": rhs}


def nonnegative(identifier, ring, value, domain=None):
    return {"kind": "nonnegative_coefficients", "id": identifier,
            "variables": list(ring.variable_names()),
            "polynomial": polynomial(ring, value),
            "domain": domain or [f"{v} >= 0" for v in ring.variable_names()]}
