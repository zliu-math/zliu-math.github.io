"""Exact algebraic certificates for Appendix B, not a proof of the input metrics.

Run with a Python containing sage.all, or Sage -c and runpy.run_path with
run_name='__main__'. No floating-point tests or external symbolic dependencies
are used.
"""

import json
from pathlib import Path
import sys
from functools import lru_cache
from itertools import combinations_with_replacement, product

from sage.all import PolynomialRing, QQ, matrix

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from certificate_format import expression_identity


def run():
    checks = []
    certificates = {}

    def record(identifier, claim, residuals, detail):
        values = list(residuals)
        bad = [str(value) for value in values if value != 0]
        checks.append({"id": identifier, "status": "FAIL" if bad else "PASS",
                       "claim": claim, "evidence": detail,
                       "residual_count": len(values), "nonzero_residuals": bad})
        return not bad

    ring = PolynomialRing(QQ, "z,t,a,b,p,q")
    z, t, a, b, p, q = ring.gens()
    field = ring.fraction_field()
    D = field((b-a)/(2*t))
    H = ((z+t)*b-(z-t)*a)/(2*t)
    H += (z-t)**2*(z+t)/(4*t**2)*(p-D)
    H += (z+t)**2*(z-t)/(4*t**2)*(q-D)
    H1 = D+(3*z*z-t*t)/(4*t*t)*(p+q-2*D)+z/(2*t)*(q-p)
    H2 = 3*z/(2*t*t)*(p+q-2*D)+(q-p)/(2*t)
    record("gluing.hermite.endpoint_jets", "Cubic interpolant matches values and first normal derivatives at both interfaces.",
           [H.subs({z: -t})-a, H.subs({z: t})-b,
            H.derivative(z).subs({z: -t})-p, H.derivative(z).subs({z: t})-q],
           "Four identities in QQ(z,t,a,b,p,q), with t != 0; each residual is exactly zero.")
    record("gluing.hermite.derivatives", "Displayed first and second derivatives are exact.",
           [H.derivative(z)-H1, H.derivative(z, 2)-H2],
           "Formal differentiation of the interpolant over the exact rational-function field.")
    certificates["hermite_second_derivative"] = str(H2)

    jets = PolynomialRing(QQ, "t,y,h,P,Q,A,B,C,E,F,J")
    jt, y, h, P, Q, A, B, C, E, F, J = jets.gens()
    jf = jets.fraction_field()
    av = h-jt*P+jt**2*A/2-jt**3*B/6+jt**4*C/24
    bv = h+jt*Q+jt**2*E/2+jt**3*F/6+jt**4*J/24
    pv = P-jt*A+jt**2*B/2-jt**3*C/6
    qv = Q+jt*E+jt**2*F/2+jt**3*J/6
    mapping = {z: jt*y, t: jt, a: av, b: bv, p: pv, q: qv}
    hom = ring.hom([mapping[v] for v in ring.gens()], jf)

    def evaluate(expression):
        return hom(expression.numerator()) / hom(expression.denominator())

    metric_remainder = jets((evaluate(H)-h)/jt)
    first_remainder = jets((evaluate(H1)-((1-y)*P+(1+y)*Q)/2)/jt)
    second_remainder = jets(evaluate(H2)+(P-Q)/(2*jt))
    record("gluing.hermite.formal_orders", "Finite Taylor jets have the claimed scaled leading orders H=h+O(t), H'=((1-y)P+(1+y)Q)/2+O(t), H''=-(P-Q)/(2t)+O(1).",
           [evaluate(H)-h-jt*metric_remainder,
            evaluate(H1)-((1-y)*P+(1+y)*Q)/2-jt*first_remainder,
            evaluate(H2)+(P-Q)/(2*jt)-second_remainder],
           "Arbitrary independent one-sided normal Taylor jets through degree four; z=t*y. All three normalized remainders coerce to a polynomial ring, so have no negative t powers. Uniform smooth-family remainder estimates remain analytic obligations.")
    certificates["formal_scaled_remainders"] = {
        "(H-h)/t": str(metric_remainder),
        "(H'-linear_interpolation)/t": str(first_remainder),
        "H''+(P-Q)/(2t)": str(second_remainder)}

    dr = PolynomialRing(QQ, "l,p11,p12,p22,q11,q12,q22")
    lam, p11, p12, p22, q11, q12, q22 = dr.gens()
    pm = matrix(dr, [[p11, p12], [p12, p22]])
    qm = matrix(dr, [[q11, q12], [q12, q22]])
    det_residual = ((1-lam)*pm+lam*qm).det()-(1-lam)*pm.det()-lam*qm.det()+lam*(1-lam)*(pm-qm).det()
    record("gluing.determinant", "The 2-by-2 determinant interpolation identity has the sign stated in the manuscript.",
           [det_residual], "Universal polynomial identity for two arbitrary symmetric 2-by-2 matrices.")
    record("gluing.tangential_gain", "Subtracting the interpolated determinant gives the nonnegative tangential correction +l(1-l) det(P-Q)/4 when 0<=l<=1 and P-Q is positive definite.",
           [-((1-lam)*pm+lam*qm).det()/4+(1-lam)*pm.det()/4+lam*qm.det()/4-lam*(1-lam)*(pm-qm).det()/4],
           "Exact identity; positive definiteness and the interval restriction are explicit mathematical premises.")
    certificates["determinant_residual"] = str(det_residual)

    # Independent connection-jet calculation at a point in slice normal
    # coordinates: H=I and tangential first derivatives of H vanish. Normal
    # derivatives, mixed derivatives, and tangential second derivatives are
    # arbitrary. This retains every tensor structure in the three collar blocks.
    n = 7
    tangents = range(1, n)
    pairs = list(combinations_with_replacement(tangents, 2))
    names = [f"p{i}{j}" for i, j in pairs]
    names += [f"q{i}{j}" for i, j in pairs]
    names += [f"c{i}{j}_{k}" for i, j in pairs for k in tangents]
    names += [f"d{i}{j}_{k}{l}" for i, j in pairs for k, l in pairs]
    cr = PolynomialRing(QQ, names)
    variables = dict(zip(names, cr.gens()))
    zero = cr.zero()

    def sym(prefix, i, j):
        i, j = sorted((i, j))
        return variables[f"{prefix}{i}{j}"]

    def dg(direction, i, j):
        if i == 0 or j == 0 or direction != 0:
            return zero
        return sym("p", i, j)

    def ddg(direction1, direction2, i, j):
        if i == 0 or j == 0:
            return zero
        i, j = sorted((i, j))
        if direction1 == direction2 == 0:
            return sym("q", i, j)
        if direction1 == 0 or direction2 == 0:
            return variables[f"c{i}{j}_{max(direction1, direction2)}"]
        k, l = sorted((direction1, direction2))
        return variables[f"d{i}{j}_{k}{l}"]

    @lru_cache(None)
    def gamma(upper, lower1, lower2):
        return (dg(lower1, lower2, upper)+dg(lower2, lower1, upper)-dg(upper, lower1, lower2))/2

    @lru_cache(None)
    def dgamma(direction, upper, lower1, lower2):
        inverse_term = -sum(dg(direction, upper, f)*gamma(f, lower1, lower2) for f in range(n))
        linear_term = (ddg(direction, lower1, lower2, upper)+ddg(direction, lower2, lower1, upper)-ddg(direction, upper, lower1, lower2))/2
        return inverse_term+linear_term

    @lru_cache(None)
    def curvature(a, b, c, d):
        # R(a,b)c = nabla_a nabla_b c - nabla_b nabla_a c.
        return dgamma(a, d, b, c)-dgamma(b, d, a, c)+sum(gamma(e, b, c)*gamma(d, a, e)-gamma(e, a, c)*gamma(d, b, e) for e in range(n))

    def linear(a, b, c, d):
        return (ddg(a, c, b, d)-ddg(a, d, b, c)-ddg(b, c, a, d)+ddg(b, d, a, c))/2

    def nonlinear(a, b, c, d):
        return sum(gamma(e, a, c)*gamma(e, b, d)-gamma(e, b, c)*gamma(e, a, d) for e in range(n))

    record("gluing.curvature.coordinate_formula", "The displayed all-lowered coordinate curvature formula has the correct convention and separates linear second derivatives from nonlinear first derivatives.",
           [curvature(a, b, c, d)-linear(a, b, c, d)-nonlinear(a, b, c, d) for a, b, c, d in product(range(n), repeat=4)],
           "2401 exact polynomial component identities from independent differentiation of connection coefficients, for arbitrary collar 2-jets in the manuscript's dimension seven at slice normal coordinates.")
    radial = []
    gauss = []
    codazzi = []
    for i, j in product(tangents, repeat=2):
        radial.append(curvature(i, 0, 0, j)+sym("q", i, j)/2-sum(sym("p", i, k)*sym("p", k, j) for k in tangents)/4)
    for i, j, k, l in product(tangents, repeat=4):
        gauss.append(curvature(i, j, k, l)-linear(i, j, k, l)-(sym("p", i, k)*sym("p", j, l)-sym("p", i, l)*sym("p", j, k))/4)
    for i, j, k in product(tangents, repeat=3):
        codazzi.append(curvature(i, j, k, 0)-(ddg(0, j, i, k)-ddg(0, i, j, k))/2)
    record("gluing.curvature.radial", "Radial block equals -H''/2+H' H^{-1} H'/4.", radial,
           "36 exact entries; H=I at the evaluation point, so H^{-1}=I. The quadratic term is a sum of squares on diagonal entries.")
    record("gluing.curvature.gauss", "Tangential Gauss block has the sign that yields K_G=K_H-det(H'|Pi)/(4 det(H|Pi)).", gauss,
           "1296 arbitrary formal tangential components in dimension seven, independently calculated from the Levi-Civita connection.")
    record("gluing.curvature.codazzi", "Mixed curvature block equals ((D_j H')_ik-(D_i H')_jk)/2 and contains no H''.", codazzi,
           "216 arbitrary formal mixed components; tangential slice Christoffels vanish at the point, so covariant derivatives there equal partial derivatives.")
    certificates["curvature_jet_model"] = {"ambient_dimension": n,
        "number_of_independent_jet_variables": len(names),
        "coordinates": "H_ij=delta_ij; tangential first derivatives H_ij,k=0; arbitrary H', H'', H' tangential derivatives and H tangential second derivatives",
        "radial_11": str(curvature(1, 0, 0, 1)),
        "tangent_1221": str(curvature(1, 2, 2, 1)),
        "mixed_1230": str(curvature(1, 2, 3, 0))}

    sr = PolynomialRing(QQ, "a0,beta,tau,C0,M,x,y")
    a0, beta, tau, C0, M, x, y = sr.gens()
    sf = sr.fraction_field()
    young_gap = sf(a0*x*x/2+2*M*M*y*y/a0-2*M*x*y)
    square = sf((a0*x-2*M*y)**2/(2*a0))
    original = a0*x*x+(beta/tau-C0)*y*y-2*M*x*y
    bounded = a0*x*x/2+(beta/tau-C0-2*M*M/a0)*y*y
    record("gluing.mixed.schur", "The all-plane lower bound follows by an exact nonnegative square, including angles depending on tau.",
           [young_gap-square, original-bounded-square],
           "Identity for x=|cos(theta)|, y=|sin(theta)| with a0>0. Gap=(a0*x-2*M*y)^2/(2*a0). A sufficient explicit choice is 0<tau<=beta/(C0+2*M^2/a0+a0/2), also subject to all earlier smallness bounds.")
    certificates["schur_square"] = str(square)
    certificates["sufficient_tau_bound"] = "beta/(C0 + 2*M^2/a0 + a0/2)"

    # Keep these factored expression strings independent of Sage's expanded
    # polynomial representations: a standard-library-only verifier parses and
    # expands the two sides afresh. All variable denominators are cleared.
    hermite_numerator = "4*t**2*((z+t)*b-(z-t)*a)+(z-t)**2*(z+t)*(2*t*p-b+a)+(z+t)**2*(z-t)*(2*t*q-b+a)"
    first_numerator = "4*t**2*(b-a)+(2*(z-t)*(z+t)+(z-t)**2)*(2*t*p-b+a)+(2*(z+t)*(z-t)+(z+t)**2)*(2*t*q-b+a)"
    first_display = "4*t**2*(b-a)+2*(3*z**2-t**2)*(t*(p+q)-b+a)+4*z*t**2*(q-p)"
    second_numerator = "(6*z-2*t)*(2*t*p-b+a)+(6*z+2*t)*(2*t*q-b+a)"
    second_display = "12*z*(t*(p+q)-b+a)+4*t**2*(q-p)"
    v = ["z", "t", "a", "b", "p", "q"]
    replayable = [
        expression_identity("gluing.hermite.value_minus", v, hermite_numerator.replace("z", "(-t)"), "8*t**3*a"),
        expression_identity("gluing.hermite.value_plus", v, hermite_numerator.replace("z", "(t)"), "8*t**3*b"),
        expression_identity("gluing.hermite.derivative_minus", v, first_numerator.replace("z", "(-t)"), "8*t**3*p"),
        expression_identity("gluing.hermite.derivative_plus", v, first_numerator.replace("z", "(t)"), "8*t**3*q"),
        expression_identity("gluing.hermite.first_display", v, first_numerator, first_display),
        expression_identity("gluing.hermite.second_display", v, second_numerator, second_display),
        expression_identity("gluing.determinant.factored", ["l", "p11", "p12", "p22", "q11", "q12", "q22"],
                            "((1-l)*p11+l*q11)*((1-l)*p22+l*q22)-((1-l)*p12+l*q12)**2",
                            "(1-l)*(p11*p22-p12**2)+l*(q11*q22-q12**2)-l*(1-l)*((p11-q11)*(p22-q22)-(p12-q12)**2)"),
        expression_identity("gluing.young.square", ["a0", "M", "x", "y"],
                            "a0**2*x**2+4*M**2*y**2-4*a0*M*x*y", "(a0*x-2*M*y)**2"),
        expression_identity("gluing.schur.full_bound", ["a0", "beta", "tau", "C0", "M", "x", "y"],
                            "(2*a0**2*tau*x**2+2*a0*(beta-C0*tau)*y**2-4*a0*tau*M*x*y)-(a0**2*tau*x**2+(2*a0*beta-2*a0*tau*C0-4*tau*M**2)*y**2)",
                            "tau*(a0*x-2*M*y)**2"),
    ]
    certificates["replayable"] = replayable

    # The two equalities required to eliminate distributional singular terms
    # are already universal endpoint polynomial identities above.
    record("gluing.interface.distributional_jump_coefficients", "Jump coefficients of the metric and first derivative vanish at both interfaces.",
           [H.subs({z: -t})-a, H.derivative(z).subs({z: -t})-p,
            H.subs({z: t})-b, H.derivative(z).subs({z: t})-q],
           "The four exact zero jumps eliminate delta-prime and delta contributions in a one-dimensional distributional second derivative. Distribution theory itself is an analytic input.")

    for identifier, claim, evidence in [
        ("gluing.analytic.uniformity", "Uniform C_X^j estimates, positivity for sufficiently small tau, and compact minima on all plane bundles.",
         "UNVERIFIED by finite algebra. Analytic audit finds the supplied argument valid for fixed smooth families on compact X with Delta>=2*b_* h and positive input sectional curvature; these hypotheses are not established by this module."),
        ("gluing.analytic.smoothing", "Common tensor convolution and localized smoothing preserve positive sectional curvature.",
         "UNVERIFIED by finite algebra. Analytic audit finds no gap: C1 matching removes singular measures; R=L(D2G)+Q(G,DG); C1 convergence controls Q; nonnegative convolution preserves the decomposable-bivector cone; C2 convergence controls the fixed smooth cutoff annuli. Bounds depend on tau after tau is fixed."),
        ("gluing.application.input_metrics", "The particular disk metrics satisfy the global positive sectional-curvature and strictly positive boundary-jump hypotheses.",
         "Outside this module: no finite Appendix B identity verifies the earlier geometric construction or its premises."),
        ("gluing.external.quantitative_bound", "Section 6 obtains K>min(c_S,c_N)/2 from Reiser-Wraith Corollary B.",
         "Primary source arXiv:2308.06996v2, Theorem A(i) and Corollary B, was read on 2026-09-25: k=1 is sectional curvature and the lower threshold may be any real kappa. This is a checked external theorem interface, not a machine proof. Appendix B alone does not assert this exact half-min constant.")]:
        checks.append({"id": identifier, "status": "UNVERIFIED", "claim": claim, "evidence": evidence})

    limitations = [
        "PASS denotes exact listed algebraic identities, not global existence or an automatic proof of the positive gluing theorem.",
        "The formal Taylor certificate uses finite jets; smooth-family Taylor remainder bounds, tangential regularity, compactness, and convergence are analytic reasoning.",
        "Curvature components are checked for generic jets in the actual ambient dimension seven at normal slice coordinates; the universal all-dimension index derivation remains the mathematical argument.",
        "Input metrics and strict boundary-jump positivity are hypotheses, not outputs of these checks.",
        "No external theorem or reference content is certified here, and no numeric samples are used.",
    ]
    return {"module": "gluing", "source_scope": "v12 Appendix B, labels eq:glue-hermite through eq:glue-localization; Section 6 labels lem:gluing and thm:main",
            "checks": checks, "certificates": certificates, "limitations": limitations}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
