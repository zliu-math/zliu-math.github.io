# Quaternionic carrier and attaching-map audit — v12

Date: 2026-09-25. Scope: `paper/submitted.tex`, Section 2 and Appendix A,
with the common-boundary interpretation in Section 6. This is a scoped
mathematical audit, not a formal proof of the main theorem.

## Result and computational evidence

No substantive error was found in the reviewed carrier, quotient-coordinate,
or attaching-map arguments. The review was performed against v12 itself,
not inferred from the earlier verification run.

The local SageMath 10.9 execution of `checks/topology.py` returned eleven
PASS groups and no FAIL group. They comprise 43 exact residual comparisons,
including quaternion multiplication, conjugation and norm identities, three
additional attaching-map identities, the infinitesimal action norm bound,
two symbolic endpoint limits, and finite label counting. Two algebraic
certificates can also be replayed by the standard-library-only verifier.

The 43 comparisons are not 43 independent theorems. In particular, label
counting does not prove that the geometric models represent those labels.

## 1. Smooth Blakers–Massey map

The formula used is

\[
b(p,w)=\cos(\pi\sqrt{s})+
 \frac{\sin(\pi\sqrt{s})}{\sqrt{s}(1-s)}wp\bar w,
\qquad s=|p|^2,
\]

on the sphere where \(|w|^2=1-s\). At zero the power series for
\(\sin(\pi\sqrt{s})/\sqrt{s}\) contains only integral powers of
\(s\). At one the numerator has a simple zero and the other denominator
factor is smooth and nonzero. Thus the displayed scalar function has smooth
extensions at both endpoints, rather than merely finite limits. The map
also has values in the unit quaternions by continuity from \(w\ne0\).

Sage checks the two limits \(\pi\) and \(\pi/2\), but the power-series
and smooth-division arguments remain mathematical reasoning. No claim of
all-orders smoothness is inferred from a numerical or symbolic limit alone.

Conjugation commutes with the quaternionic exponential. Together with
norm preservation this proves the stated equivariance, including the
removable set by continuity. Pointwise integer powers preserve smoothness
and equivariance.

## 2. Principal bundle, star action and free quotient

The transition \(u_S=g_n(x)u_N\) is smooth on the overlap and commutes
with right multiplication. It therefore specifies the stated principal
right bundle. The usual product-chart construction in Appendix A gives a
Hausdorff, second-countable smooth manifold; no principal-bundle
classification is needed for its existence.

The star formula is well defined across the transition because

\[
g_n(qxq^{-1})(qu_N)=qg_n(x)u_N.
\]

It extends across each pole in linear disk coordinates. If \(qu=u\),
then \(q=1\), so there are no exceptional non-free orbits at a pole.
The principal right action and the star action commute but are different
actions. No identification of their orbit spaces is made.

The disk coordinate \(Y=u^{-1}\zeta u\) is invariant under the star
action. Every orbit has exactly one representative \((Y,1)\). The
coordinate and inverse are smooth at the center as well as elsewhere,
giving a smooth disk quotient, not just a homeomorphism away from the center.

Sage checks the generic quaternionic identities underlying invariance and
commutation after clearing norms. Freeness, chart smoothness and the quotient
manifold argument are not outputs of finite algebra.

## 3. Marked attaching map and every integer iterate

For representatives of the same boundary point,

\[
y_S=u_N^{-1}g_n(x)^{-1}xg_n(x)u_N
    =g_n(y_N)^{-1}y_Ng_n(y_N).
\]

The second equality uses equivariance and the verified conjugation algebra.
It is not an assertion that the two extending boundary markings coincide.

For \(\sigma(x)=b(x)^{-1}xb(x)\), equivariance gives
\(b(\sigma(x))=b(x)\). The same is true for
\(\widehat\sigma(x)=b(x)xb(x)^{-1}\). Substitution then proves
that \(\widehat\sigma\) is a smooth inverse. Induction in both integer
directions gives

\[
\sigma^n(x)=b(x)^{-n}xb(x)^n.
\]

The new T09–T11 checks verify the underlying generic transition,
inverse-composition and two-step multiplication identities. They do not
replace the proof that \(b\) remains constant along the orbit or the
all-integer induction.

## 4. Smoothness across the seam

v12 explicitly addresses the point that matching two disk maps only on
their boundaries does not by itself establish a smooth map across the seam.
The signed radial coordinates are

\[
R_N(\rho-1)\quad\hbox{and}\quad R_S(1-\rho),
\]

on the northern and southern collars respectively; both equal \(t-a\).
The angular coordinate is \(y_N\) on one side and
\(\sigma^{-n}(y_S)\) on the other. The proposed map and its inverse
preserve these collar coordinates. This proves smoothness across the
seam in the stated gluing smooth structure.

Changing the cut from \(a\) to \(\pi/2\) by an increasing radial
diffeomorphism linear near the endpoints is smooth at both disk centers.
It preserves the angular attaching map. The orientation is explicitly
chosen by comparison with the cited model, avoiding an unstated sign
choice in the label \(n\).

## 5. External classification interface

The primary source [Durán–Püttmann–Rigas, Theorem 1 and Section 4]
(https://arxiv.org/html/math/0610349v1#S4) was read on 2026-09-25.
Its Section 4 uses exactly \(\sigma(p,w)=\overline{b(p,w)}(p,w)b(p,w)\)
and gluing by its \(n\)-th iterate. Theorem 1 identifies the resulting
oriented type with \(n\bmod 28\). These are the interfaces required
by the manuscript's coordinate comparison.

Corollary 2.2 classifies the principal bundle by \(n\bmod12\), not its
star quotient. Forgetting equivariant star-action data is therefore not a
valid argument that quotients with equal bundle class must be diffeomorphic.

This source was checked for applicability, not re-proved or formalized.
The residue enumeration and the list of non-Milnor labels are bookkeeping
under that external classification, not a Sage proof of classification.

## 6. Boundary geometry interface

Using the same north gauge on both boundary collars is legitimate even
though the north gauge does not extend across the southern disk center.
In that common gauge both source metrics and star actions coincide.
Hence the induced boundary metrics coincide there. Their identification is
represented by \(\sigma^n\), not the identity, when expressed in the
two markings that extend over the respective disks.

The derivative map at \(u=1\) is
\(L=(F_a^{-1}I,-r_a^{-1}K_x)\). Consequently the quotient cometric
is \(LL^*\). The verified sum-of-squares identity gives
\(K_x^*K_x\le4I\) at every orbit rank. There is no hidden assumption
of a constant-rank conjugation action: freeness comes from the separate
left multiplication on the fibre coordinate.

The outward unit radial normals are horizontal. Restriction of the source
second fundamental forms to common horizontal lifts is therefore valid.
Their fibre terms cancel and their angular terms add to
\((\mu_N-\mu_S)|X|^2\). The graph condition forces \(X\ne0\) for
a nonzero quotient tangent vector. This verifies the sign mechanism of
the boundary jump, conditional on the earlier filling constructions and
their specified endpoint data. The detailed generic graph and eigenvalue
identities are checked separately in `checks/north.py`.

## What this audit does not certify

It does not prove existence of the southern or northern positive metrics,
the analytic small-parameter estimates, or smoothing. A correct attaching
map and a complete list of labels do not imply positive curvature. Those
are separate edges in the proof dependency chain.
