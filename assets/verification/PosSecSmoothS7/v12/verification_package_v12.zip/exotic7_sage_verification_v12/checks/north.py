"""Exact independent checks of v12 northern filling and boundary comparison.

Source: v12_clean.tex, Sections 5--6 (lines 1409--1947 in the input).
Earlier package symbols uN/us are now muN/muS, matching mu_N/mu_S.

Run with Sage's Python. No sampling of floating-point planes is used.
The finite algebraic checks do not assert formal verification of global analysis.
"""
import json
import sys
from pathlib import Path
from sage.all import QQ, PolynomialRing, matrix, vector, SR, exp, var

sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from certificate_format import identity, nonnegative, expression_identity


def _warped_curvature_certificate():
    """Reconstruct curvature from the metric's exact 2-jet, not its claimed R.

    Use the full source dimension 1+6+3=10, not a representative slice.
    Each sphere uses stereographic coordinates with metric
    (1+|x|^2/4)^(-2) sum(dx_i^2), which is Euclidean to first order
    and has sectional curvature +1 at the origin.
    """
    ring = PolynomialRing(QQ, names="F,Fp,Fpp,r,rp,rpp")
    F, Fp, Fpp, r, rp, rpp = ring.gens()
    field = ring.fraction_field()
    n = 10
    angular = tuple(range(1,7))
    fibre = tuple(range(7,10))
    metric = [field(1)] + [F*F]*6 + [r*r]*3
    derivative = {}
    second = {}
    for i, warp, first, two, factor in (
        [(i,F,Fp,Fpp,angular) for i in angular]
        +[(i,r,rp,rpp,fibre) for i in fibre]):
        derivative[i,i,0] = 2*warp*first
        second[i,i,0,0] = 2*(first*first + warp*two)
        for k in factor:
            second[i,i,k,k] = -warp*warp
    dg = lambda i,j,k: field(derivative.get((i,j,k),0))
    ddg = lambda i,j,k,l: field(second.get((i,j,k,l),0))
    Gamma = {}
    dGamma = {}
    for up in range(n):
        for i in range(n):
            for j in range(n):
                bracket = dg(up,j,i)+dg(up,i,j)-dg(i,j,up)
                Gamma[up,i,j] = bracket/(2*metric[up])
                for k in range(n):
                    dbracket = (ddg(up,j,i,k)+ddg(up,i,j,k)
                                -ddg(i,j,up,k))
                    dGamma[up,i,j,k] = (dbracket/(2*metric[up])
                        -dg(up,up,k)*bracket/(2*metric[up]**2))

    def R(up, acted, i, j):
        return (dGamma[up,j,acted,i]-dGamma[up,i,acted,j]
            +sum(Gamma[m,j,acted]*Gamma[up,i,m]
                 -Gamma[m,i,acted]*Gamma[up,j,m] for m in range(n)))

    pairs = [(i,j) for i in range(n) for j in range(i+1,n)]
    coeffs = []
    off_count = 0
    for i,j in pairs:
        for k,l in pairs:
            component = metric[k]*R(k,l,i,j)
            if (i,j) != (k,l):
                assert component == 0, ((i,j,k,l),component)
                off_count += 1
            else:
                sectional = component/(metric[i]*metric[j])
                if i == 0:
                    expected = -Fpp/F if j in angular else -rpp/r
                elif j in angular:
                    expected = (1-Fp*Fp)/(F*F)
                elif i in fibre:
                    expected = (1-rp*rp)/(r*r)
                else:
                    expected = -Fp*rp/(F*r)
                assert sectional == expected, ((i,j),sectional,expected)
                coeffs.append({"pair": [i,j], "coefficient": str(sectional)})
    return {"dimension":n, "off_diagonal_entries_exactly_zero":off_count,
            "diagonal_entries":coeffs,
            "method":"Metric 2-jet -> Christoffel symbols and derivatives -> curvature"}


def run():
    checks = []
    certificates = {}
    replayable = []
    certificates["replayable"] = replayable
    limitations = []

    def passed(identifier, claim, evidence):
        checks.append({"id":identifier,"status":"PASS",
                       "claim":claim,"evidence":evidence})

    # K_x xi = 2(xi cross p, xi cross w_im, 0).
    R = PolynomialRing(QQ,names="p1,p2,p3,w1,w2,w3,w0,z1,z2,z3")
    p1,p2,p3,w1,w2,w3,w0,z1,z2,z3 = R.gens()
    p=vector(R,[p1,p2,p3]); w=vector(R,[w1,w2,w3])
    z=vector(R,[z1,z2,z3])
    K=matrix(R,7,3,lambda i,j:
        (2*vector(R,[int(k==j) for k in range(3)]).cross_product(p)[i]
         if i<3 else
         2*vector(R,[int(k==j) for k in range(3)]).cross_product(w)[i-3]
         if i<6 else 0))
    Id=matrix.identity(R,3)
    gram=4*((p.dot_product(p)+w.dot_product(w))*Id
            -p.column()*p.row()-w.column()*w.row())
    assert K.transpose()*K == gram
    x=vector(R,[p1,p2,p3,w1,w2,w3,w0])
    assert x*K == vector(R,[0,0,0])
    slack=4*z.dot_product(z)-(K*z).dot_product(K*z)
    sos=4*(w0*w0*z.dot_product(z)+p.dot_product(z)**2+w.dot_product(z)**2)
    sphere=x.dot_product(x)-1
    assert slack-sos == -4*sphere*z.dot_product(z)
    replayable.append(identity("N01-K-norm-sphere-SOS",R,slack-sos,
                               -4*sphere*z.dot_product(z)))
    zsq="(z1**2+z2**2+z3**2)"
    sphere_expr="(p1**2+p2**2+p3**2+w1**2+w2**2+w3**2+w0**2-1)"
    cross_expr="((z2*p3-z3*p2)**2+(z3*p1-z1*p3)**2+(z1*p2-z2*p1)**2+(z2*w3-z3*w2)**2+(z3*w1-z1*w3)**2+(z1*w2-z2*w1)**2)"
    sos_expr="(w0**2*"+zsq+"+(p1*z1+p2*z2+p3*z3)**2+(w1*z1+w2*z2+w3*z3)**2)"
    replayable.append(expression_identity("N01-unexpanded-K-norm-SOS",R.variable_names(),
        "4*"+zsq+"-4*"+cross_expr+"-4*"+sos_expr,
        "-4*"+sphere_expr+"*"+zsq))
    certificates["K_operator_bound"]={
        "gram":"4((|p|^2+|Im w|^2)I-pp^T-(Im w)(Im w)^T)",
        "unit_sphere_slack":"4(w0^2 |xi|^2 + <p,xi>^2 + <Im w,xi>^2)",
        "tangency_residual":"0"}
    passed("N01","The infinitesimal conjugation map is tangent and ||K_x|| <= 2.",
           "Exact polynomial Gram identity and sum-of-squares certificate on |x|=1.")

    # Generic matrices certify the graph, quotient differential and cometric.
    G=PolynomialRing(QQ,names=["F","r"]+["k%d%d"%(i,j) for i in range(6) for j in range(3)])
    F,r=G.gens()[:2]; GF=G.fraction_field()
    Kg=matrix(GF,6,3,G.gens()[2:]); I6=matrix.identity(GF,6)
    T=-F/r*Kg.transpose()
    generators=(F*Kg).stack(r*matrix.identity(GF,3))
    graph=I6.stack(T)
    L=(I6/F).augment(-Kg/r)
    assert generators.transpose()*graph == matrix(GF,3,6,0)
    assert L*generators == matrix(GF,6,3,0)
    S=I6+F*F/(r*r)*Kg*Kg.transpose()
    assert graph.transpose()*graph == S
    assert L*graph == S/F
    assert L*L.transpose() == I6/(F*F)+Kg*Kg.transpose()/(r*r)
    certificates["horizontal_and_cometric"]={
        "T":"-(F/r)K^T", "generator_orthogonality_residual":"0 (3 by 6 matrix)",
        "differential_kernel_residual":"0 (6 by 3 matrix)",
        "graph_Gram":"S=I+(F^2/r^2)KK^T",
        "differential_on_graph":"S/F",
        "cometric":"LL^T=I/F^2+KK^T/r^2"}
    passed("N02","The star-horizontal graph and boundary cometric have the stated factors and signs.",
           "Generic 6 by 3 K; all matrix identities are exact over a rational function field.")

    A=PolynomialRing(QQ,names=["x%d"%i for i in range(3)]+["y%d"%i for i in range(3)]
        +["t%d%d"%(i,j) for i in range(3) for j in range(3)]+["lam","mu"])
    ag=A.gens(); X=vector(A,ag[:3]); Y=vector(A,ag[3:6])
    Tm=matrix(A,3,3,ag[6:15]); lam,mu=ag[15:]
    U=Tm*X; V=Tm*Y
    M=X.column()*V.row()-Y.column()*U.row()
    tensor_norm=sum(v*v for v in M.list())
    expansion=(X.dot_product(X)*V.dot_product(V)+Y.dot_product(Y)*U.dot_product(U)
               -2*X.dot_product(Y)*U.dot_product(V))
    assert tensor_norm == expansion
    replayable.append(identity("N03-mixed-area-expansion",A,tensor_norm,expansion))
    assert lam*V-mu*U == Tm*(lam*Y-mu*X)
    wedge=sum((X[i]*Y[j]-X[j]*Y[i])**2 for i in range(3) for j in range(i+1,3))
    assert wedge == X.dot_product(X)*Y.dot_product(Y)-X.dot_product(Y)**2
    replayable.append(identity("N03-Gram-determinant",A,wedge,
                         X.dot_product(X)*Y.dot_product(Y)-X.dot_product(Y)**2))
    # Determinant-one orthogonalization X -> X, Y -> Y-cX preserves the tensor.
    Ac=PolynomialRing(A,"c"); c=Ac.gen()
    XX=vector(Ac,X); YY=vector(Ac,Y); TT=matrix(Ac,Tm)
    changed=XX.column()*(TT*(YY-c*XX)).row()-(YY-c*XX).column()*(TT*XX).row()
    assert changed == matrix(Ac,M)
    certificates["area_estimates"]={
        "tensor_identity":"|X|^2|TY|^2+|Y|^2|TX|^2-2<X,Y><TX,TY>",
        "orthogonalized_bound":"2||T||^2 |X wedge Y|^2",
        "substitution":"||T|| <= 2F/r gives 8F^2/r^2",
        "radial_identity":"lambda TY-mu TX=T(lambda Y-mu X)",
        "shear_invariance":"Exact for arbitrary scalar c"}
    passed("N03","Both area estimates are valid, including the mixed-area factor 8.",
           "Exact tensor, Gram determinant, radial linearity and determinant-one shear identities; apply operator norm after orthogonalization.")

    certificates["warped_curvature"]=_warped_curvature_certificate()
    passed("N04","The complete doubly warped curvature operator has exactly the five claimed blocks.",
           "Independently reconstructed from the full 10-dimensional metric 2-jet: 45 diagonal entries match and 1980 off-diagonal entries vanish exactly.")

    Fv,delt,s=var("Fv delt s")
    speed=exp(-Fv**2/(2*delt**2))
    acceleration=speed.diff(Fv)*speed
    assert (acceleration+Fv/delt**2*speed**2).simplify_full()==0
    assert (-acceleration/Fv-exp(-Fv**2/delt**2)/delt**2).simplify_full()==0
    # Compare Taylor jets to an extra order beyond the manuscript.
    jet=s-s**3/(6*delt**2)+7*s**5/(120*delt**4)
    defect=(jet.diff(s)-exp(-jet**2/(2*delt**2))).series(s,5).truncate().expand()
    assert defect==0
    certificates["F_profile"]={"Fpp":"-F*(Fp)^2/delta^2",
        "radial_curvature":"delta^(-2)*exp(-F^2/delta^2)",
        "series":"s-s^3/(6 delta^2)+7s^5/(120 delta^4)+O(s^7)",
        "ODE_jet_defect_through_degree_4":"0"}
    passed("N05","The profile derivatives, curvature coefficients and center Taylor jet are correct.",
           "Exact symbolic differentiation and vanishing ODE Taylor defect.")

    B=PolynomialRing(QQ,"t"); t=B.gen()
    assert t**4-4*t+3 == (t-1)**2*(t*t+2*t+3)
    replayable.append(identity("N06-minimizer-factorization",B,t**4-4*t+3,
                               (t-1)**2*(t*t+2*t+3)))
    replayable.append(expression_identity("N06-unexpanded-minimizer",["t"],
        "t**4-4*t+3","(t-1)**2*(t**2+2*t+3)"))
    replayable.append(nonnegative("N06-positive-minimizer-factor",B,t*t+2*t+3,["t >= 0"]))
    assert QQ(8)/3 > 0 and (QQ(8)/3)**4 > 8
    certificates["elementary_bound"]={
        "normalized_minimum_residual_factorization":"t^4-4t+3=(t-1)^2(t^2+2t+3)",
        "normalization":"x=8^(1/4)*t",
        "minimum":"4/(3*8^(1/4)) > 1/2",
        "strict_comparison_after_fourth_power":str((QQ(8)/3)**4-8),
        "sinh_step":"2 sinh(x^2/2) >= x^2+x^6/24; omitted power series terms are positive"}
    passed("N06","The global elementary lower bound is valid for every x>0.",
           "Exact minimizer factorization and rational fourth-power comparison; positive convergent sinh series supplies the preceding inequality.")

    C=PolynomialRing(QQ,"C").gen()
    cf=C.parent().fraction_field()
    loss=cf(C)/(32*(1+C))
    radial_margin=QQ(3)/4-loss
    assert radial_margin-QQ(15)/32 == cf(9+8*C)/(32*(1+C))
    replayable.append(identity("N07-radial-margin-numerator",C.parent(),
                     24*(1+C)-C-15*(1+C),9+8*C))
    replayable.append(nonnegative("N07-positive-radial-reserve",C.parent(),9+8*C,["C >= 0"]))
    assert QQ(15)/32-QQ(1)/5 == QQ(43)/160
    # exp(-1/4)>=3/4 from exp(1/4)<=sum(1/4)^n=4/3.
    certificates["radial_inequality"]={
        "exp_lower_bound":"exp(-1/4) >= 3/4",
        "loss_coefficient":"C/(32(1+C))",
        "margin_above_15_over_32":str(radial_margin-QQ(15)/32),
        "off_support":"P=delta^(-2) exp(-F^2/delta^2) >= p_*",
        "comparison_with_p_star":"exp(-T_*)<=exp(-4)<=1/5<15/32"}
    passed("N07","The radial criterion and the claimed uniform P bound follow with strict reserve.",
           "Rational positive-coefficient certificate; elementary exponential-series bounds avoid numerical approximations.")

    # All non-polynomial factors enter through established inequalities.
    assert QQ(32)/128 == QQ(1)/4
    assert QQ(1)/4 < QQ(1)/2
    certificates["angular_inequality"]={
        "density":"d/r^3 <= 8q_s/r_a^2=4A0 Fa exp(-eps A0|cos a|) <= 4A0 Fa",
        "loss":"8FF'r'/r^3 <= 32A0 Fa FF' <= FF'/(4(1+C_eta)delta^3)",
        "positive_coefficient":"(1-F'^2)/F^2 > FF'/(2delta^3)",
        "loss_fraction":"loss / ((1-F'^2)/F^2) < 1/(2(1+C_eta)) <= 1/2"}
    passed("N08","The angular curvature criterion holds uniformly and leaves at least half the angular coefficient.",
           "Exact coefficient arithmetic combines delta^3 A0 Fa <= 1/(128(1+C_eta)), the density bound and N06.")

    ep,Av,Fa,ca=var("ep Av Fa ca")
    ra2=ep*exp(ep*Av*ca); qs=ep*Av*Fa/2
    assert (8*qs/ra2-4*Av*Fa*exp(-ep*Av*ca)).simplify_full()==0
    assert (qs/ra2).limit(ep=0,dir="+") == Av*Fa/2
    certificates["parameter_coexistence"]={
        "ell_upper_bound":"0 < ell_N <= Fa exp(Fa^2/(2delta^2)) < infinity",
        "explicit_northern_threshold":"eps_N=min(1, 1/(1+A0|cos a|), 1/(2A0 Fa), 1/(A0 Fa ell_N))",
        "q_ell_bound":"eps < eps_N implies q_s ell_N < 1/2",
        "slope_bound":"exp(eps A0|cos a|/2)<2; d< A0 Fa eps^(3/2) <= A0 Fa eps < 1/2",
        "common_choice":"0<eps<min(eps_S,eps_N) is nonempty whenever fixed eps_S>0",
        "boundary_density_limit":"q_s/r_a^2 -> A0 Fa/2"}
    passed("N09","The small-parameter northern inequalities and matching boundary data coexist.",
           "An explicit positive eps_N is supplied after delta and finite ell_N are fixed; no lower bound on eps conflicts with the southern upper bounds.")

    # Concrete exact witness: a=5pi/6, A0=1, Fa=1/2, delta=1/16,
    # an admissible smooth eta with C_eta<=8, eps=2^-200.
    de=QQ(1)/16; aa=QQ(1); fa=QQ(1)/2; cc=QQ(8); ee=QQ(1)/2**200
    delta_product=de**3*aa*fa*(1+cc)
    assert delta_product < QQ(1)/128
    ell_upper=QQ(2)**63  # Fa*e^32 < (1/2)*4^32.
    qell_upper=ee*aa*fa/2*ell_upper
    assert qell_upper < QQ(1)/2
    d_squared_upper=ee**3/4
    assert d_squared_upper < 1
    certificates["exact_northern_parameter_witness"]={
        "parameters":"a=5pi/6; A0=1; Fa=1/2; delta=1/16; C_eta<=8; eps=2^-200",
        "delta_product":str(delta_product), "delta_limit":"1/128",
        "T_star":"64", "ell_upper_bound":"2^63 (using e<4)",
        "q_s_ell_upper_bound":str(qell_upper),
        "d_squared_upper_bound":str(d_squared_upper),
        "scope":"Witness certifies northern requirements only, not the particular southern A0 or connection of a chosen n."}
    passed("N10","There is an explicit exact witness for the northern parameter inequalities.",
           "All final comparisons are rational; e<4 gives the finite length and boundary derivative bounds.")

    E=PolynomialRing(QQ,names="F,r,b,muN,muS,qs")
    f,rr,b,un,us,q=E.gens(); EF=E.fraction_field()
    graph_norm=1+f*f*b/(rr*rr)
    north_shape=(un+q*f*f*b/(rr*rr))/graph_norm
    south_shape=(-us-q*f*f*b/(rr*rr))/graph_norm
    eigen=rr*rr*(un-us)/(rr*rr+f*f*b)
    assert north_shape+south_shape == eigen
    margin=rr*rr*(un-us)/(rr*rr+4*f*f)
    gap=eigen-margin
    expected=rr*rr*(un-us)*f*f*(4-b)/((rr*rr+f*f*b)*(rr*rr+4*f*f))
    assert gap == expected
    replayable.append(identity("N11-fibre-shape-cancellation",E,
        un*rr*rr+q*f*f*b-us*rr*rr-q*f*f*b,rr*rr*(un-us)))
    replayable.append(identity("N11-boundary-margin-gap",E,
        rr*rr*(un-us)*(rr*rr+4*f*f)-rr*rr*(un-us)*(rr*rr+f*f*b),
        rr*rr*(un-us)*f*f*(4-b)))
    replayable.append(expression_identity("N11-unexpanded-boundary-margin",E.variable_names(),
        "r**2*(muN-muS)*(r**2+4*F**2)-r**2*(muN-muS)*(r**2+F**2*b)",
        "r**2*(muN-muS)*F**2*(4-b)"))
    Ksharp=K.subs({p1:1,p2:0,p3:0,w1:0,w2:0,w3:0,w0:0})
    assert sorted(matrix(QQ,Ksharp.transpose()*Ksharp).eigenvalues()) == [0,4,4]
    certificates["boundary_shapes"]={
        "north_eigenvalue":str(north_shape), "south_eigenvalue":str(south_shape),
        "sum_eigenvalue":str(eigen), "margin_gap_factorization":str(expected),
        "sharp_point":"x=(i,0): nonzero K^T K eigenvalues are 4,4",
        "muN":"exp(-Fa^2/(2delta^2))/Fa > 0", "muS":"cot(a)<0",
        "notation_correspondence":"v11 u_N,u_s -> v12 mu_N,mu_S; no mathematical change"}
    passed("N11","The outward shape terms cancel exactly in the fibre directions; the stated boundary margin is positive and sharp.",
           "Exact rational eigenvalue identity and nonnegative gap factorization for 0<=b<=4; sharp eigenvalue 4 verified.")

    certificates["quotient_lower_bound"]={
        "P":"P>=delta^(-2) exp(-Fa^2/delta^2)",
        "Q":"Q>= (1-exp(-Fa^2/delta^2))/(2Fa^2)",
        "monotonicity":"d[(1-e^-y)/y]/dy=((1+y)e^-y-1)/y^2<0 by e^y>1+y",
        "graph_norm":"||graph||^2<=H*=1+16Fa^2/ra^2",
        "area_distortion":"||Lambda^2 graph||^2 <= H*^2",
        "quotient_bound":"K>=H*^-2 min(p*,q*)>0 by the nonnegative O'Neill term"}
    passed("N12","The announced positive quotient lower bound follows from the verified coefficients.",
           "N07/N08 plus elementary exponential monotonicity and the second exterior-power operator norm inequality.")

    limitations.extend([
        "Sage checks algebraic identities, exact inequalities and jets, not a formal proof of smooth ODE inversion, smooth cutoff existence, compactness, or smooth polar extension. These steps have been reviewed analytically and no defect was found.",
        "The north proof uses standard submersion and warped-product geometry. The quotient's global disk marking and the identity-to-sigma^n transition are inherited from the earlier topology section, not independently certified by this module.",
        "Boundary equality is proved conditional on the southern connection vanishing in the stated common north gauge and the southern boundary formulas. This module does not certify the southern positive-curvature theorem.",
        "The explicit rational witness is for north alone. General coexistence with a selected southern filling follows conditionally from that filling supplying a positive eps_S and fixed A0.",
        "No claim of complete manuscript correctness or a formal proof assistant verification follows from these finite exact checks."
    ])
    checks.append({"id":"N13","status":"UNVERIFIED",
        "claim":"Global analytic/topological hypotheses needed to turn the exact north certificates into a complete filling and gluing theorem.",
        "evidence":"Not formalized: smooth eta and inverse profile, global quotient marking, earlier southern theorem and the subsequent gluing theorem. These are distinguished from the exact checks above."})
    return {"checks":checks,"certificates":certificates,"limitations":limitations}


if __name__ == "__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
