"""Fail on a source revision not matching the separately reviewed v12 contract."""
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from formula_contract import inventory, sha256

ROOT = Path(__file__).resolve().parents[1]


def run():
    contract = json.loads((ROOT/'docs/reviewed_formula_contract.json').read_text())
    raw = (ROOT/'paper/submitted.tex').read_bytes()
    text = raw.decode('utf-8')
    actual = inventory(text)
    expected = contract['labeled_displays']
    checks = [
        {'id':'S01','status':'PASS' if sha256(raw)==contract['source_sha256'] else 'FAIL',
         'claim':'The submitted source is exactly the reviewed v12 file, not a previous manuscript',
         'evidence':{'actual_sha256':sha256(raw),'reviewed_sha256':contract['source_sha256']}},
        {'id':'S02','status':'PASS' if actual==expected and actual else 'FAIL',
         'claim':'Every inventoried labeled display matches the separately frozen source contract',
         'evidence':{'display_blocks':len(actual),'labels':sum(len(x['labels']) for x in actual)}},
        {'id':'S03','status':'PASS' if raw==(ROOT/'paper/revised.tex').read_bytes() else 'FAIL',
         'claim':'This v12 release does not silently change the supplied manuscript',
         'evidence':'Both source copies are preserved byte-for-byte.'}]
    return {'checks':checks,'certificates':{'version':'v12','source_sha256':sha256(raw),
            'labeled_displays':actual,'replayable':[]},
            'limitations':['Hashes establish source identity, not formula truth or a correct translation. Human review establishes correspondence to the independently derived code.',
                           'The inventory covers labeled equation/align/gather environments, not every inline or unlabeled formula. The full-source hash binds all remaining text.']}


if __name__=='__main__':
    print(json.dumps(run(),indent=2))
