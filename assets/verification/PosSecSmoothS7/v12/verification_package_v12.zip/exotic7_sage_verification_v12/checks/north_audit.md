# Independent v12 northern-filling and boundary audit

## Scope and conclusion

Input examined: `paper/submitted.tex`, Sections 5 and 6, corresponding to
lines 1409--1947 of `v12_clean.tex`. The formulas and their geometric use
were rederived, rather than accepted because the preceding verification
package passed. No mathematical error was found in these sections in this
review. This is a scoped internal review, not an independent certification
of the entire manuscript or its topology and southern-filling premises.

The earlier symbols `u_N,u_s` are now `mu_N,mu_S`, respectively. Both mean
the angular logarithmic derivatives at the boundary. They are not fibre
coordinates. The exact test variables have been updated accordingly.

`north.py` produces 12 PASS groups, one UNVERIFIED dependency group and
12 replayable exact certificates. Its curvature reconstruction now uses
the entire 10-dimensional source, rather than a representative
five-dimensional slice: 45 diagonal entries agree and 1,980 off-diagonal
entries vanish. `interval_bounds.py` adds six PASS groups, one replayable
polynomial certificate, and 224 actual directed-rounding interval cells.
The interval records are not rechecked by the rational-only certificate
checker; rerunning the Sage interval module is the reproduction operation.

## 1. Horizontal graph, all orbit types and all planes

Write `x=(p,w_im,w_0)` on the unit six-sphere. Differentiating conjugation
gives `K_x xi=2(xi cross p,xi cross w_im,0)`. Direct calculation gives

```
K_x^* K_x = 4((|p|^2+|w_im|^2)I-p p^T-w_im w_im^T),
4|xi|^2-|K_x xi|^2
    =4(w_0^2|xi|^2+<p,xi>^2+<w_im,xi>^2).
```

Thus `||K_x||<=2` at every point, including points with a smaller
conjugation orbit. The full star generator has Gram matrix
`F^2 K_x^*K_x+r^2 I`, which stays strictly positive since `r>0`.
Nothing in the argument inverts `K_x` or presumes constant rank.

In orthonormal components the generator is `(F K_x xi,r xi)`. Orthogonality
is exactly `U=-(F/r)K_x^*X`. The resulting graph is injective, including
the radial coordinate. For `U=TX,V=TY`, the two area estimates follow from

```
lambda V-mu U=T(lambda Y-mu X),
|X tensor TY-Y tensor TX|^2
 =|X|^2|TY|^2+|Y|^2|TX|^2-2<X,Y><TX,TY>.
```

The change `Y -> Y-<X,Y>X/|X|^2` has determinant one and leaves both
the tensor and `X wedge Y` unchanged. On the resulting orthogonal pair,
the second identity is bounded by `2||T||^2 |X wedge Y|^2`. This proves
the manuscript's factors 4 and 8. If the angular pair is dependent the
mixed tensor vanishes; no division by a vanishing area is required.

If both base-area squares vanish, the two projected vectors in
`R partial_s plus T_x S^6` are dependent. Injectivity then makes the
original horizontal vectors dependent. Consequently their strict positive
coefficients control every nondegenerate horizontal plane, not just pure
radial or pure tangential ones.

## 2. Curvature independently reconstructed from the metric

For `ds^2+F^2 h_S6+r^2 h_S3`, use local stereographic coordinates on each
unit sphere with factor `(1+|z|^2/4)^(-2)`. At the origin of those
coordinates the first angular derivatives of the metric vanish and its
second angular derivatives are known explicitly. Retaining independent
symbols `F,F',F'',r,r',r''`, the code constructs the metric 2-jet,
Christoffel symbols, their derivatives, and the curvature tensor.

This uses one radial, six angular and three fibre coordinates. The
resulting curvature operator on the 45 coordinate bivectors is diagonal.
Its five coefficients are precisely

```
-F''/F,  -r''/r,  (1-F'^2)/F^2,  (1-r'^2)/r^2,  -F'r'/(Fr).
```

There are 6 radial--angular, 3 radial--fibre, 15 angular--angular,
3 fibre--fibre and 18 angular--fibre diagonal entries. All 1,980
off-diagonal entries are zero. These are rational-function identities,
not numerical tests of particular planes. Expanding an arbitrary
bivector against these blocks gives the full curvature numerator used
in the paper, including the mixed loss. Its geometric interpretation
still uses the standard curvature tensor and warped-product conventions.

## 3. Fixed angular geometry before the fibre scale

The map `J(F)=integral_0^F exp(z^2/(2 delta^2)) dz` is strictly increasing
and smooth. Its inverse defines the desired profile until `F=F_a`, at
the finite length `ell_N=J(F_a)`. The inverse function theorem, not a
computer ODE solver, supplies the global inverse on this compact range.
The inverse is odd at zero and

```
F'=exp(-F^2/(2 delta^2)),
F''=-(F/delta^2)(F')^2,
F(s)=s-s^3/(6 delta^2)+7s^5/(120 delta^4)+O(s^7).
```

The code verifies the differential identities and the jet through an
order beyond that required in the manuscript. Hence the radial and
angular sectional curvatures of the base tend to `delta^(-2)` at the
center. Oddness, the derivative 1, and the fact that `r` is constant near
zero supply polar smoothness. The star tangent there lies wholly in the
fibre, so the horizontal space is the whole base tangent space.

The northern quantifiers are important: first choose `delta`, then the
finite (possibly very large) `ell_N`, and only then `epsilon`. With
`c=|cos a|`, an explicit sufficient northern threshold is

```
epsilon_N=min(1, 1/(1+A0*c), 1/(2*A0*F_a),
              1/(A0*F_a*ell_N)).
```

For `0<epsilon<epsilon_N`, one has `q_s ell_N<1/2` and
`d=r_a q_s<1/2<1`. The latter follows from
`exp(epsilon A0 c/2)<2` and `epsilon<1`.
Then `r_a/2<=r<=r_a`, `r'=d eta`, and `r''=d eta'/delta`.
This threshold is compatible with any separately established positive
southern threshold for the same fixed `a,A0`; no uniform threshold for
all `n` is asserted or needed.

## 4. Uniform scalar estimates and the mixed loss

On the support of `r''`, `s<=delta/2` and `F<=s`, so

```
-F''/F >= exp(-1/4)/delta^2,
4F^2 r''/r^3 <= 4 A0 F_a C_eta delta
             <= C_eta/(32(1+C_eta)delta^2).
```

This leaves more than `15/(32 delta^2)`. Outside that support the loss
is zero. The estimate is genuinely uniform, not a fixed-plane limiting
argument.

For the angular coefficient, put `x=F/delta`. The positive-term expansion
of `sinh` gives

```
2 sinh(x^2/2)/x^3 >= 1/x+x^3/24 >= 4/(3*8^(1/4)) > 1/2.
```

The minimization reduces to
`t^4-4t+3=(t-1)^2(t^2+2t+3)` after `x=8^(1/4)t`.
Combining this with the parameter condition gives

```
8FF'r'/r^3 <= FF'/(4(1+C_eta)delta^3)
           < (1/2)(1-F'^2)/F^2.
```

Thus the mixed loss consumes less than half the positive angular
coefficient. The retained fibre-area coefficient is nonnegative because
`r'<1`. No unestimated cross term remains in the reconstructed curvature
operator.

Let `T_*=F_a^2/delta^2`, `p_*=delta^(-2)exp(-T_*)` and
`q_*=(1-exp(-T_*))/(2F_a^2)`. Radial control and monotonicity of
`(1-exp(-y))/y` give `P_rad>=p_*` and `P_ang>=q_*`.
The graph has squared norm at most `H_*=1+16F_a^2/r_a^2`, so its second
exterior power has squared norm at most `H_*^2`. Dividing by the full
horizontal bivector norm gives the stated positive `c_N`. This is
exactly where the proof controls arbitrary moving planes uniformly.
O'Neill's extra term is nonnegative and can be discarded for this bound.

## 5. Boundary comparison and outward-normal signs

At `u=1`, the quotient differential is
`L=(F_a^(-1)I,-r_a^(-1)K_x)`. Its cometric is `LL^*`, giving
`h^(-1)=F_a^(-2)I+r_a^(-2)K_xK_x^*`. The generic symbolic check uses
an arbitrary 6-by-3 `K`, not only selected orbit representatives.

On common horizontal lifts the outward normals are `partial_s` on the
north and `-partial_t` on the south. The common fibre logarithmic
derivative therefore enters the two second fundamental forms with
opposite signs:

```
B_N = mu_N |X|^2+q_s |U|^2,
phi_n^* B_S = -mu_S |X|^2-q_s |U|^2.
```

Their sum is `(mu_N-mu_S)|X|^2`. Since `mu_N>0>mu_S`, this is strictly
positive on a nonzero horizontal lift. For a `K_xK_x^*` eigenvalue
`b` in `[0,4]`, division by the induced boundary norm gives

```
r_a^2(mu_N-mu_S)/(r_a^2+F_a^2 b).
```

The difference from the claimed lower bound factors as

```
r_a^2(mu_N-mu_S)F_a^2(4-b)
 /((r_a^2+F_a^2 b)(r_a^2+4F_a^2)).
```

Every factor has the required sign. The bound is attained at `(i,0)`,
where the nonzero eigenvalues of `K_x^*K_x` are 4 and 4. This verifies
the sharpness claim as well as the margin. Boundary equality itself
still depends on the source metrics really having the same common-gauge
boundary form, and the marked map being the stated `sigma^n`; these are
global geometric premises from the preceding sections.

## 6. What the additional interval module does

It uses Sage `RealIntervalField(200)` with outward rounding, not ordinary
floating-point sampling. The interval `[1/2,4]` is exactly partitioned
into 224 rational cells of width `1/64`. The enclosure of
`2 sinh(x^2/2)/x^3` has lower endpoint greater than `1/2` on every cell.
Every cell endpoint and every output endpoint is exported as an exact
rational string. The tails are closed analytically: for `0<x<=1/2`,
the positive series gives `R>=1/x>=2`; for `x>=4`, it gives
`R>=x^3/24>=8/3`. This is not a claim that finitely many cells cover
the unbounded interval.

It also encloses the strict constants `exp(-1/4)-1/32`, `exp(-4)`, and
`4/(3*8^(1/4))`. A concrete northern-only witness

```
a=5*pi/6, A0=1, F_a=1/2, delta=1/16,
C_eta<=8, epsilon=2^(-200)
```

has certified `q_s ell_N<1/2`, `0<d<1`, `c_N>0` and `c_B>0`.
The length is bounded by `F_a exp(F_a^2/(2 delta^2))`; its numerical
integral need not be approximated. A smooth cutoff with `C_eta<=8`
exists by convolving the slope-8 ramp on `[5/16,7/16]` with a
nonnegative smooth unit-mass kernel supported in `[-1/32,1/32]`.

This witness is deliberately not advertised as valid southern data for
any `n`: the southern theorem can require a different `A0`. It is not a
closed-sphere example or a numerical certificate for all 28 types.

The rational-only replay checker independently verifies the exported
polynomial identity, but not transcendental enclosures. Reproducing the
latter requires Sage and its interval library. The package must preserve
this distinction in the public report and website.

## Remaining non-computational dependencies

The code does not formalize the inverse function theorem, smooth
cutoff construction, polar smoothness theorem, O'Neill's formula,
global smooth quotient/disk marking, the southern filling theorem, or
the curvature-preserving gluing theorem. Their mathematical uses above
were reviewed, but a successful script is not an end-to-end formal
proof of these statements or of the all-types main theorem.
