"""Exact scalar certificates for a nonempty common small-parameter interval.

The bounds depend on finite, fixed geometric constants, not on numerical
values claimed to bound a particular clutching map. Compactness and smoothness
justify finiteness in the human proof; this module does not compute those suprema.
"""
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sage.all import QQ, PolynomialRing
from certificate_format import expression_identity


def run():
    R = PolynomialRing(QQ, "x,e,C,D,M,k,L,P,A,F,c,ell")
    x,e,C,D,M,k,L,P,A,F,c,ell = R.gens()
    K = R.fraction_field()
    checks, replay = [], []

    def record(identifier, claim, residuals, evidence):
        residuals = list(residuals)
        checks.append({"id": identifier,
                       "status": "PASS" if all(v == 0 for v in residuals) else "FAIL",
                       "claim": claim, "evidence": evidence,
                       "nonzero_residuals": [str(v) for v in residuals if v != 0]})

    record("P01", "A/(B(1+x)) gives slack A/(1+x) in A-B*epsilon*x at the threshold",
           [K(A-C*(A/(C*(1+x)))*x)-K(A/(1+x))],
           "Universal rational identity for A,B>0 and x>=0; expressions below instantiate it.")
    replay.append(expression_identity("threshold_positive_slack", ["A","x"],
                                     "A*(1+x)-A*x", "A"))
    record("P02", "For 0<=epsilon<=1, epsilon^3<=epsilon",
           [e-e**3-e*(1-e)*(1+e)],
           "Exact factorization epsilon-epsilon^3=epsilon(1-epsilon)(1+epsilon).")
    replay.append(expression_identity("cubic_to_linear_bound", ["e"], "e-e**3", "e*(1-e)*(1+e)"))
    bounds = [
        {"name": "epsilon<=1", "upper": "1", "purpose": "higher powers can be bounded by epsilon"},
        {"name": "absolute exponential", "upper": "1/(2*(1+P0))", "purpose": "epsilon*P0<1/2<log(2)"},
        {"name": "2 epsilon M0", "upper": "1/(2*(1+M0))", "purpose": "2 epsilon M0<1"},
        {"name": "epsilon D0 M0", "upper": "1/(1+D0*M0)", "purpose": "epsilon D0 M0<1"},
        {"name": "horizontal curvature", "upper": "kappa/(8*C*(1+M0**2))", "purpose": "8 C epsilon M0^2<kappa"},
        {"name": "horizontal-vertical Young loss", "upper": "kappa/(64*C**2*(1+M0**2))", "purpose": "64 C^2 epsilon M0^2<kappa"},
        {"name": "Hessian loss", "upper": "Lambda/(4*(1+D0**2))", "purpose": "epsilon D0^2<Lambda/4"},
        {"name": "vertical loss", "upper": "1/(2*(1+D0**2))", "purpose": "2 epsilon^3 D0^2<1"},
        {"name": "mixed Young loss", "upper": "Lambda/(32*C**2*(1+D0**2*M0**2))", "purpose": "32 C^2 epsilon^3 D0^2 M0^2<Lambda"},
        {"name": "north exponential", "upper": "1/(2*(1+A0*c))", "purpose": "exp(epsilon A0 c)<2"},
        {"name": "north fibre slope", "upper": "1/(2*(1+A0*Fa))", "purpose": "epsilon A0 Fa<1/2"},
        {"name": "north positive radius", "upper": "1/(1+A0*Fa*ell_N)", "purpose": "q_s ell_N<1/2"}]
    # Verify all concrete rational instantiations of the master slack identity.
    instances = [
        (K(1)/2, K(1), P), (K(1), K(2), M), (K(1), K(1), D*M),
        (K(k), K(8*C), M*M), (K(k), K(64*C*C), M*M),
        (K(L)/4, K(1), D*D), (K(1), K(2), D*D),
        (K(L), K(32*C*C), D*D*M*M),
        (K(1)/2, K(1), A*c), (K(1)/2,K(1),A*F),
        (K(1),K(1),A*F*ell)]
    residuals=[]
    for target, coefficient, nonnegative in instances:
        threshold = target/(coefficient*(1+nonnegative))
        residuals.append(target-coefficient*threshold*nonnegative-target/(1+nonnegative))
    record("P03", "Every displayed scalar upper bound satisfies its corresponding linear constraint",
           residuals,
           "11 exact rational identities. Cubic constraints also use P02. Finiteness and signs of geometric constants are explicit premises.")
    # If eps*A0*Fa<1/2, exp(eps*A0*c)<2, eps<=1 then d^2<eps/8<=1/8.
    record("P04", "Northern d<1 follows with a fixed strict reserve from the chosen thresholds",
           [QQ(2)/4*(QQ(1)/2)**2-QQ(1)/8],
           "d^2=epsilon*(epsilon A0 Fa)^2 exp(epsilon A0 c)/4 < epsilon/8 <=1/8.")
    record("P05", "The allocated mixed-loss budget leaves exactly epsilon Lambda/8",
           [QQ(1)/2-QQ(1)/16-QQ(1)/8-QQ(1)/8-QQ(1)/16-QQ(1)/8],
           "The mixed coefficient budget is exactly epsilon Lambda/8. Other reserves are kappa/2 and 1/(8 epsilon).")
    checks.append({"id":"P06", "status":"UNVERIFIED",
                   "claim":"The concrete n-dependent curvature suprema and smooth cutoff derivative bounds are finite, and all interval/exponential monotonicity hypotheses apply",
                   "evidence":"This is established by the smooth compact geometric construction and elementary analysis; no finite CAS assertion formalizes these global statements."})
    return {"checks":checks,
            "certificates":{"common_upper_bounds":bounds,
                "definition":"epsilon_* is the minimum of the twelve strictly positive displayed upper bounds; choose 0<epsilon<epsilon_*",
                "fixed_constants":"P0=sup|phi|, D0=sup|d phi|, M0,M1>=0 finite; kappa,Lambda,A0,Fa,ell_N>0; c=|cos a|>0; C=4",
                "geometric_premises":["sec(g_B)>=kappa", "-Hess(phi)>=Lambda*g_B", "Lambda>=16*C*M0^2+64*C^2*(M1+1)^2/kappa+4", "A0*c>=Lambda", "delta and smooth eta obey the northern conditions"],
                "length_bound":"0<ell_N<=Fa*exp(Fa^2/(2*delta^2))<infinity for fixed Fa,delta>0",
                "domain":"No common epsilon across n is required; choose it separately after fixing each n's data.",
                "replayable":replay},
            "limitations":["The bounds are symbolic functions of fixed finite constants. This is not a numerical evaluation of M0 or M1 for 28 individual bundles.",
                           "log(2)>1/2 follows by integrating 1/t>1/2 over [1,2); inverse-function and compactness arguments are supplied in the human proof."]}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
