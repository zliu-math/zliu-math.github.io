"""v12: exact quaternion algebra, attaching-map algebra and type labels.

These checks do not computationally classify smooth structures. In particular,
the integer iterate formula uses smooth equivariance as a mathematical premise.
"""
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sage.all import QQ, PolynomialRing, matrix, vector, SR, pi, sin, sqrt
from certificate_format import identity, expression_identity


def qmul(a, b):
    a0, a1, a2, a3 = a
    b0, b1, b2, b3 = b
    return (a0*b0-a1*b1-a2*b2-a3*b3,
            a0*b1+a1*b0+a2*b3-a3*b2,
            a0*b2-a1*b3+a2*b0+a3*b1,
            a0*b3+a1*b2-a2*b1+a3*b0)


def conjugate(q):
    return (q[0], -q[1], -q[2], -q[3])


def norm2(q):
    return sum(x*x for x in q)


def run():
    checks, replay, certificate = [], [], {}

    def record(identifier, claim, residuals, evidence):
        residuals = list(residuals)
        ok = all(x == 0 for x in residuals)
        checks.append({"id": identifier, "status": "PASS" if ok else "FAIL",
                       "claim": claim, "evidence": evidence,
                       "residual_count": len(residuals),
                       "nonzero_residuals": [str(x) for x in residuals if x != 0]})

    R = PolynomialRing(QQ, names=[f"{q}{j}" for q in ("a", "b", "c") for j in range(4)])
    a, b, c = [tuple(R.gens()[4*i:4*i+4]) for i in range(3)]
    ab = qmul(a, b)
    record("T01", "Quaternion multiplication is associative", 
           [x-y for x,y in zip(qmul(ab,c),qmul(a,qmul(b,c)))],
           "Four polynomial identities over QQ in 12 independent real variables.")
    record("T02", "Quaternion norm is multiplicative and conjugation reverses products",
           [norm2(ab)-norm2(a)*norm2(b)] +
           [x-y for x,y in zip(conjugate(ab),qmul(conjugate(b),conjugate(a)))],
           "Hamilton multiplication was expanded from components; no sampled values.")
    replay.append(expression_identity("quaternion_norm_product", list(R.variable_names()),
        "(a0*b0-a1*b1-a2*b2-a3*b3)**2 + (a0*b1+a1*b0+a2*b3-a3*b2)**2 + "
        "(a0*b2-a1*b3+a2*b0+a3*b1)**2 + (a0*b3+a1*b2-a2*b1+a3*b0)**2",
        "(a0**2+a1**2+a2**2+a3**2)*(b0**2+b1**2+b2**2+b3**2)"))
    # Clearing denominators proves invariance for nonzero q,u; unit q,u are a special case.
    qu = qmul(a,b)
    qxqbar = qmul(qmul(a,c),conjugate(a))
    lhs = qmul(qmul(conjugate(qu),qxqbar),qu)
    rhs = tuple(norm2(a)**2*z for z in qmul(qmul(conjugate(b),c),b))
    record("T03", "The quotient coordinate u^{-1} x u is invariant under (x,u)->(q x q^{-1},qu)",
           [x-y for x,y in zip(lhs,rhs)],
           "Four generic denominator-cleared polynomial identities; nonzero norms required for inverses.")
    record("T04", "Bundle transition and right principal action commute",
           [x-y for x,y in zip(qmul(qmul(a,b),c),qmul(a,qmul(b,c)))],
           "Associativity applied to g_n(x), u, h; smoothness of g_n is a separate analytic premise.")
    # Generic attaching-map identity. Use a=u, b=g(x), c=x and clear
    # the norms of the fibre coordinate. The equivariance identification
    # g(u^{-1}xu)=u^{-1}g(x)u is a separate geometric premise.
    y = qmul(qmul(conjugate(a), c), a)
    gy = qmul(qmul(conjugate(a), b), a)
    left_attach = qmul(qmul(conjugate(gy), y), gy)
    right_attach = qmul(qmul(conjugate(a),
                            qmul(qmul(conjugate(b), c), b)), a)
    record("T09", "The marked transition is conjugation by g_n(y), after imposing the equivariance premise",
           [x-norm2(a)**2*y for x, y in zip(left_attach, right_attach)],
           "Four exact denominator-cleared identities in arbitrary quaternion components; u and g_n(x) are unit in the geometric application.")
    inverse_composition = qmul(qmul(b, qmul(qmul(conjugate(b), c), b)), conjugate(b))
    record("T10", "Opposite conjugations are inverse when the conjugating quaternion is unit",
           [x-norm2(b)**2*y for x, y in zip(inverse_composition, c)],
           "The polynomial identity is C_b(C_bbar(x))=|b|^4 x. The manifold inverse formula additionally uses b(sigma(x))=b(x), proved using equivariance in the manuscript.")
    two_steps = qmul(qmul(conjugate(b), qmul(qmul(conjugate(b), c), b)), b)
    b_squared = qmul(b, b)
    one_power = qmul(qmul(conjugate(b_squared), c), b_squared)
    record("T11", "The induction step for iterated conjugation has the required multiplication order",
           [x-y for x, y in zip(two_steps, one_power)],
           "A generic two-step conjugation identity, not sampling of the nonlinear Blakers--Massey map. The all-integer induction is human reasoning from this group law and invariance of b along sigma-orbits.")
    # Infinitesimal conjugation K, including the scalar component of w.
    S = PolynomialRing(QQ, names=["p1","p2","p3","w0","w1","w2","w3","v1","v2","v3"])
    p1,p2,p3,w0,w1,w2,w3,v1,v2,v3 = S.gens()
    p,w,v = vector(S,[p1,p2,p3]),vector(S,[w1,w2,w3]),vector(S,[v1,v2,v3])
    K = matrix(S, 7, 3)
    for j in range(3):
        e = vector(S,[int(k == j) for k in range(3)])
        column = list(2*e.cross_product(p)) + [S(0)] + list(2*e.cross_product(w))
        K.set_column(j,column)
    expected = 4*((p.dot_product(p)+w.dot_product(w))*matrix.identity(S,3) - p.column()*p.row() - w.column()*w.row())
    record("T05", "K^* K = 4((|p|^2+|Im w|^2)I-p p^T-Im(w) Im(w)^T)",
           (K.transpose()*K-expected).list(), "Exact 3-by-3 matrix identity.")
    area = p.dot_product(p)+w.dot_product(w)+w0*w0
    gap = 4*area*v.dot_product(v) - (K*v).dot_product(K*v)
    squares = 4*((p.dot_product(v))**2 + (w.dot_product(v))**2 + w0*w0*v.dot_product(v))
    record("T06", "On |x|=1, ||K_x v||^2 <= 4||v||^2, including all orbit ranks",
           [gap-squares], "The deficit is the displayed sum of squares, valid for every real vector v.")
    replay.append(expression_identity("infinitesimal_conjugation_norm_bound", list(S.variable_names()),
        "4*(p1**2+p2**2+p3**2+w0**2+w1**2+w2**2+w3**2)*(v1**2+v2**2+v3**2)"
        "-4*((v2*p3-v3*p2)**2+(v3*p1-v1*p3)**2+(v1*p2-v2*p1)**2"
        "+(v2*w3-v3*w2)**2+(v3*w1-v1*w3)**2+(v1*w2-v2*w1)**2)",
        "4*((p1*v1+p2*v2+p3*v3)**2+(w1*v1+w2*v2+w3*v3)**2+w0**2*(v1**2+v2**2+v3**2))"))
    t = SR.var("bm_t")
    # Substitute s=t^2 for the s=0 removable singularity and s=1-t for the other.
    left = (sin(pi*t)/(t*(1-t*t))).limit(bm_t=0)
    right = (sin(pi*sqrt(1-t))/(sqrt(1-t)*t)).limit(bm_t=0)
    record("T07", "Blakers--Massey scalar factor has endpoint limits pi and pi/2",
           [left-pi,right-pi/2], "Exact symbolic limits. Limits alone are not an all-orders smoothness proof.")
    classes = list(range(28))
    orbits = sorted({tuple(sorted({n,(-n)%28})) for n in classes})
    record("T08", "Residues 0,...,27 give 28 labels and orientation reversal gives 15 orbits",
           [len(set(classes))-28,len(orbits)-15],
           "Finite modular bookkeeping only; the geometric interpretation uses DPR Theorem 1.")
    certificate.update({"quaternion_ring": str(R),
        "K_matrix": [[str(x) for x in row] for row in K.rows()],
        "K_norm_deficit_sum_of_squares": str(squares),
        "bm_endpoint_limits": [str(left),str(right)],
        "oriented_labels": classes, "orientation_orbits": orbits,
        "nonmilnor_unoriented_labels": [2,5,9,12], "replayable": replay})
    return {"module": "topology", "source_scope": "v12 Section 2, labels eq:BM, eq:equiv, eq:principal, eq:star, lem:topology, eq:clutching; Appendix A",
        "checks": checks, "certificates": certificate,
        "limitations": [
            "DPR Theorem 1 and its Section 4 identify the attaching map with class n mod 28; this is an externally cited theorem, not a Sage classification.",
            "Equivariance of the exponential, smooth removable extensions, smooth free quotients, and the integer iterate argument are mathematical proofs documented in docs/PROOF_SCOPE.md.",
            "This module does not infer all-28 curvature existence from enumeration of residues."]}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
