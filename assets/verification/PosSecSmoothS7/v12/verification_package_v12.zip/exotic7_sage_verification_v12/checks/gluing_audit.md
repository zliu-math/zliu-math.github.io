# Strict gluing audit — v12

Date: 2026-09-25. Scope: Section 6 and all of Appendix B of
`paper/submitted.tex`. The conclusion of this audit is conditional on the
input metrics having the stated positivity and boundary data.

## Result

No substantive algebraic sign error or analytic gap was found in the
strict gluing argument as stated. This does not certify that the specific
disk construction satisfies its hypotheses.

The local SageMath 10.9 run of `checks/gluing.py` returned eleven PASS
groups, four explicitly UNVERIFIED-by-computation groups, and no FAIL.
It checked 3,966 exact residuals. The generic collar-jet calculation now
uses ambient dimension seven, the dimension of the actual application,
rather than dimension four in the earlier package:

| Check | Exact component comparisons |
| --- | ---: |
| All-lowered coordinate curvature formula | 2,401 |
| Radial block | 36 |
| Tangential Gauss block | 1,296 |
| Mixed Codazzi block | 216 |
| Interpolation, determinant, square and jump identities | 17 |

Nine unexpanded arithmetic identities are included for independent
standard-library certificate replay. The thousands of Sage jet checks
are additional executable evidence, not thousands of independent
standalone certificates.

## 1. Normal convention and positive jump

With the coordinate increasing from north to south, the outward normals
are \(+\partial_z\) and \(-\partial_z\). Therefore

\[
P_0-Q_0=2(B_N+\phi^*B_S)=\Delta\ge2b_*h.
\]

The sign is consistent with convex boundaries having positive outward
second fundamental form. The north-to-south fibre slopes agree and cancel
in the sum of outward forms. A positive jump in the angular derivatives
remains. Neither a coordinate change nor a normal-sign switch is being
used to conceal a boundary mismatch.

## 2. Cubic interpolation and regularity

The Hermite polynomial has precisely the four claimed endpoint jets.
Differentiation gives the two displayed derivative formulas. On the
rescaled interval \(z=\tau y\), \(|y|\le1\), substitution of arbitrary
independent smooth-side Taylor jets gives

\[
H=h+O(\tau),\qquad
H'=(1-\lambda)P_0+\lambda Q_0+O(\tau),\qquad
H''=-\Delta/(2\tau)+O(1).
\]

The code checks the algebraic orders using independent jets through
degree four. Uniform tangential remainder bounds are instead justified
by Taylor's theorem for the fixed smooth tensor families on compact
\(X\). The constants need not be independent of the earlier metric
construction parameters: those parameters have already been fixed.

The endpoint equalities hold as identities of smooth tensors on \(X\).
They imply matching of tangential as well as normal first derivatives.
Consequently the glued metric is \(C^1\), locally \(C^{1,1}\), and
piecewise smooth. Its second weak derivatives have no Dirac measure.
Sage verifies the zero jump coefficients; distributional differentiation
itself is not a computationally proved premise.

## 3. Curvature tensor signs

The code independently differentiates the Levi–Civita connection from
formal metric jets in slice normal coordinates. It does not simply
rearrange the three asserted block formulas. All normal derivatives,
mixed derivatives and tangential second derivatives are independent.

It reproduces

\[
R_{izzj}=-\tfrac12H''_{ij}
 +\tfrac14H'_{ik}H^{kl}H'_{lj},
\]

the tangential Gauss block, and the Codazzi block. In particular the
mixed block contains no \(H''\), which is essential because
\(H''\) has size \(1/\tau\). The result uses the manuscript's convention
\(\sec(A\wedge B)=\langle R(A,B)B,A\rangle/|A\wedge B|^2\).

At a point of the seven-dimensional collar, choosing normal coordinates
for its six-dimensional slice causes no loss in these tensor identities.
The separate general-metric coordinate formula used in the smoothing
argument is checked on these jets and has a standard coordinate
derivation. Its validity for arbitrary metrics in arbitrary dimensions
is not claimed to follow just from this finite test.

## 4. Tangential reserve

The determinant identity is checked for arbitrary symmetric two-by-two
matrices. Its minus sign becomes a plus sign when inserted into the
Gauss sectional-curvature formula:

\[
K_{G_\tau}(\Pi)
 =(1-\lambda)K_{g_N}(\Pi)+\lambda K_{g_S}(\Pi)
 +\tfrac14\lambda(1-\lambda)\det_\Pi\Delta+O(\tau).
\]

The plane basis is normalized in the fixed metric \(h\). The determinant
of \(H\) on this plane is \(1+O(\tau)\), so no vanishing denominator
is suppressed. Positivity of the boundary curvatures and compactness of
the tangential plane bundle yield the common reserve \(a_0>0\).

## 5. Arbitrary moving planes

For ambient dimension at least three, every plane has a basis of the
form \(w,\cos\theta\,u+\sin\theta\,\partial_z\), with
\(u,w\) tangential and orthonormal. For a radial plane a spare
tangential vector can be chosen because the slice dimension is at least
two. Ambient dimension two is handled separately in the manuscript.

The exact nonnegative square is

\[
\frac{a_0}{2}x^2+\frac{2M^2}{a_0}y^2-2Mxy
 =\frac{(a_0x-2My)^2}{2a_0},
\qquad x=|\cos\theta|,\ y=|\sin\theta|.
\]

Thus choosing

\[
0<\tau\le\frac{\beta_0}
 {C_0+2M^2/a_0+a_0/2}
\]

in addition to the earlier smallness conditions gives a positive bound
uniform in \(\theta\). Planes with angles depending on \(\tau\)
are included. The argument does not exchange
\(\forall\Pi\,\exists\tau_\Pi\) with
\(\exists\tau\,\forall\Pi\).

## 6. Tensor-valued smoothing

The convolution is in one fixed vector space
\(\operatorname{Sym}^2T_x^*X\) for each \(x\), with one common
nonnegative kernel. Coordinate changes on \(X\) are independent of
the normal variable. This makes the construction intrinsic to the
product collar and avoids componentwise patching inconsistencies.

The all-lowered curvature tensor decomposes as

\[
R(G)=\mathcal L(D^2G)+\mathcal Q(G,DG),
\]

with constant-coefficient linear \(\mathcal L\) and continuous smooth
\(\mathcal Q\) on uniformly positive metrics. Matching first jets
removes singular measures; convolution therefore commutes with the
linear second-derivative part. Uniform \(C^1\) convergence controls
the nonlinear error, even though \(C^2\) convergence fails at the
interface. This distinction is essential and is correctly made.

The averaged curvature tensors are evaluated on the same decomposable
bivector under the product identification. Uniform metric comparison
gives a fixed positive lower bound for their sectional numerators.
It is not necessary to assume that the entire curvature operator is
positive on all bivectors. The proof uses only the decomposable cone.

After fixing \(\tau\), the smoothing width \(\nu\) is chosen small
enough for this positive margin. No false uniformity in both parameters
is needed. The cutoff transition annuli avoid the interface, so ordinary
\(C^2\) convergence there justifies localization. Constants from the
fixed cutoff may be large, but are independent of the subsequently
shrinking \(\nu\).

These convergence, compactness and distributional facts remain analytic
proof obligations rather than PASS assertions from finite algebra. The
manuscript supplies their arguments; the code marks them UNVERIFIED by
computation, not disproved.

## 7. External gluing interface and final lower bound

[Reiser–Wraith, Theorem A(i) and Corollary B]
(https://arxiv.org/html/2308.06996v2) was read on 2026-09-25.
The required hypotheses are isometric compact boundaries and a
positive-semidefinite sum of the second fundamental forms. The case
\(k=1\) is sectional curvature; Corollary B allows any real strict
lower threshold. The manuscript has the stronger strictly positive
boundary sum, and its normal convention agrees with that source.

The precise final threshold \(\tfrac12\min(c_S,c_N)\) is justified
by this external quantitative theorem, not by the particular numerical
reserve produced inside Appendix B. Both disks have curvature strictly
above that threshold. The source supplies smoothing localized near the
boundary. Its theorem is checked for applicability, not machine-proved.

## 8. Dependency boundary

The strict gluing lemma is conditional: one must already have both
positive disk metrics and the specified boundary isometry and positive
shape sum. Passing the interpolation identities cannot establish those
inputs. Conversely, the theorem does not supply a positive-curvature
connected-sum operation for arbitrary positively curved closed manifolds.
Its boundary hypotheses are substantive geometric requirements.

No modification of the v12 manuscript was needed in this reviewed scope.
