"""Mechanical source integrity and proof-location inventory, not proof validation."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


ROOT=Path(__file__).resolve().parents[1]


def run():
    text=(ROOT/"paper/revised.tex").read_text()
    original=(ROOT/"paper/submitted.tex").read_text()
    labels=re.findall(r"\\label\{([^}]+)\}", text)
    refs=re.findall(r"\\(?:ref|eqref)\*?\{([^}]+)\}",text)
    refs+=re.findall(r"\\hyperref\[([^]]+)\]",text)
    citations=[]
    for body in re.findall(r"\\cite(?:\[[^]]*\])*\{([^}]+)\}",text):
        citations.extend(s.strip() for s in body.split(','))
    bibliography=re.findall(r"\\bibitem\{([^}]+)\}",text)
    duplicate=[k for k,n in Counter(labels).items() if n>1]
    missing=sorted(set(refs)-set(labels))
    missing_citations=sorted(set(citations)-set(bibliography))
    checks=[
      {"id":"D01","status":"PASS" if not duplicate else "FAIL","claim":"Revised LaTeX labels are unique","evidence":{"duplicates":duplicate,"labels":len(labels)}},
      {"id":"D02","status":"PASS" if not missing else "FAIL","claim":"All ref/eqref/hyperref targets exist","evidence":{"missing":missing}},
      {"id":"D03","status":"PASS" if not missing_citations else "FAIL","claim":"All citation keys have bibliography entries","evidence":{"missing":missing_citations}},
    ]
    statement_pattern=r"\\begin\{(theorem|lemma|proposition)\}(.*?)\\end\{\1\}"
    source_blocks=re.findall(statement_pattern,original,re.S)
    revised_blocks=re.findall(statement_pattern,text,re.S)
    checks.append({"id":"D04","status":"PASS" if source_blocks==revised_blocks else "FAIL",
                   "claim":"All nine theorem, lemma and proposition statements agree byte-for-byte with the supplied v12",
                   "evidence":{"statement_blocks":len(source_blocks),"entire_source_unchanged":text==original}})
    inventory=[]
    for match in re.finditer(r"\\label\{([^}]+)\}",text):
        before=text[:match.start()]
        sections=list(re.finditer(r"\\section\{([^}]+)\}",before))
        inventory.append({"label":match.group(1),"line":before.count('\n')+1,
                          "section":sections[-1].group(1) if sections else "front matter"})
    return {"checks":checks,"certificates":{
        "submitted_sha256":hashlib.sha256(original.encode()).hexdigest(),
        "revised_sha256":hashlib.sha256(text.encode()).hexdigest(),
        "submitted_duplicate_labels":[k for k,n in Counter(re.findall(r"\\label\{([^}]+)\}",original)).items() if n>1],
        "label_inventory":inventory,
        "citation_keys":sorted(set(citations)),"replayable":[]},
        "limitations":["Document consistency checks do not assess the truth of mathematical statements or the correctness of external references."]}


if __name__=='__main__':
    print(json.dumps(run(),indent=2))
