"""Genuine directed-rounding interval checks of v12 scalar bounds.

This is not interval verification of all sectional curvatures or all n.
Sage RealIntervalField (MPFI/MPFR) encloses the specified elementary
functions at 200 bits. Every domain cell and output endpoint is archived
as an exact rational string. The standard-library certificate checker
replays only the separately marked polynomial certificate, NOT the
transcendental interval computation; rerun this module for that computation.
"""
import json
import sys
from pathlib import Path
from sage.all import QQ, RealIntervalField

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from certificate_format import expression_identity


def run():
    rif = RealIntervalField(200)
    checks = []
    certificates = {
        "precision_bits": 200,
        "interval_engine": "Sage RealIntervalField / MPFI / MPFR",
        "rounding": "Outward; endpoint strings are exact binary-rational values.",
        "scope": "Scalar inequalities in v12 northern estimates only.",
        "independent_replay_scope": "Only entries under replayable; interval records require Sage recomputation.",
        "replayable": [],
    }

    def endpoints(value):
        return {"lower": str(value.lower().exact_rational()),
                "upper": str(value.upper().exact_rational())}

    def passed(identifier, claim, evidence):
        checks.append({"id": identifier, "status": "PASS",
                       "claim": claim, "evidence": evidence})

    # Exact rational tiling; neither machine floats nor random points enter.
    cells = [(QQ(1)/2+QQ(j)/64, QQ(1)/2+QQ(j+1)/64)
             for j in range(224)]
    assert cells[0][0] == QQ(1)/2 and cells[-1][1] == 4
    assert all(a < b for a,b in cells)
    assert all(cells[j][1] == cells[j+1][0] for j in range(223))
    passed("I01", "The rational cells cover [1/2,4] without a gap.",
           "224 closed rational intervals of width 1/64, exact adjacency checks.")

    elementary_rows = []
    lower_bounds = []
    for j,(a,b) in enumerate(cells):
        x = rif(a,b)
        value = 2*(x*x/2).sinh()/x**3
        lo = value.lower().exact_rational()
        assert lo > QQ(1)/2, (j,a,b,value)
        lower_bounds.append(lo)
        elementary_rows.append({"cell": j, "domain": [str(a),str(b)],
                                "enclosure": endpoints(value)})
    certificates["elementary_middle"] = {
        "formula": "2*sinh(x^2/2)/x^3",
        "domain": ["1/2", "4"], "cells": elementary_rows,
        "minimum_of_enclosure_lower_endpoints": str(min(lower_bounds)),
        "asserted_threshold": "1/2",
    }
    passed("I02", "The elementary ratio is greater than 1/2 on every point of [1/2,4].",
           "All 224 outward-rounded interval lower endpoints are greater than the exact rational 1/2.")

    # Analytic tails use positivity of the convergent sinh series. That
    # analytic fact is stated, not misrepresented as an interval sample.
    assert QQ(2) > QQ(1)/2 and QQ(4)**3/24 == QQ(8)/3
    assert QQ(8)/3 > QQ(1)/2
    certificates["elementary_tails"] = {
        "analytic_input": "For x>0 the convergent sinh series gives R(x)>=1/x+x^3/24.",
        "small_domain": "0<x<=1/2", "small_lower_bound": "2",
        "large_domain": "x>=4", "large_lower_bound": "8/3",
        "scope": "Rational endpoint comparisons checked; convergence and positive-term comparison are human analytic inputs.",
    }
    certificates["replayable"].append(expression_identity(
        "I03-tail-minimizer-polynomial", ["t"],
        "t**4-4*t+3", "(t-1)**2*(t**2+2*t+3)"))
    passed("I03", "Exact endpoint comparisons close the small and large tails, conditional on the positive sinh-series bound.",
           "Small tail R>=2 and large tail R>=8/3; both exceed 1/2. Tail reasoning is analytic, not finite sampling.")

    exponential_quarter = (-rif(1)/4).exp()
    radial_reserve = exponential_quarter-rif(1)/32
    pstar_comparison = (-rif(4)).exp()
    assert radial_reserve.lower().exact_rational() > QQ(15)/32
    assert pstar_comparison.upper().exact_rational() < QQ(15)/32
    minimum_ratio = 4/(3*rif(8).sqrt().sqrt())
    assert minimum_ratio.lower().exact_rational() > QQ(1)/2
    certificates["scalar_reserves"] = {
        "exp(-1/4)-1/32": endpoints(radial_reserve),
        "exp(-4)": endpoints(pstar_comparison),
        "4/(3*8^(1/4))": endpoints(minimum_ratio),
        "comparisons": ["exp(-1/4)-1/32 > 15/32",
                        "exp(-4) < 15/32", "4/(3*8^(1/4)) > 1/2"],
    }
    passed("I04", "The stated strict exponential and fourth-root reserves have rigorous interval separation.",
           "Three outward-rounded enclosures separated from their exact rational thresholds.")

    # A concrete NORTHERN-ONLY witness, not one chosen for any southern n.
    eps = QQ(1)/2**200
    delta = QQ(1)/16
    fa = QQ(1)/2
    a0 = QQ(1)
    ceta = QQ(8)
    ca = rif(3).sqrt()/2                 # |cos(5*pi/6)|
    ra2 = rif(eps)*(rif(eps)*ca).exp()
    ra = ra2.sqrt()
    qs = rif(eps*a0*fa/2)
    ell_upper = rif(fa)*(rif(fa**2/(2*delta**2))).exp()
    qell_upper = qs*ell_upper
    d = ra*qs
    assert delta <= fa/2
    assert delta**3 <= 1/(128*a0*fa*(1+ceta))
    assert qell_upper.upper().exact_rational() < QQ(1)/2
    assert d.upper().exact_rational() < 1
    assert d.lower().exact_rational() > 0
    certificates["north_witness"] = {
        "a": "5*pi/6", "A0": "1", "Fa": "1/2", "delta": "1/16",
        "C_eta_upper": "8", "epsilon": str(eps),
        "cos_absolute": endpoints(ca), "r_a_squared": endpoints(ra2),
        "ell_N_upper_bound_enclosure": endpoints(ell_upper),
        "q_s_times_length_upper_bound_enclosure": endpoints(qell_upper),
        "d_enclosure": endpoints(d),
        "smooth_eta_existence": "Convolve the ramp on [5/16,7/16], slope 8, with a nonnegative C-infinity unit-mass kernel supported in [-1/32,1/32]. This has eta=0 below 1/4, eta=1 above 1/2, and sup|eta'|<=8.",
        "scope": "Northern inequalities only. A0=1 is NOT claimed to satisfy the southern connection requirements for any n.",
    }
    passed("I05", "The concrete northern-only parameter witness obeys both epsilon conditions.",
           "Rigorous enclosures show q_s ell_N<1/2 and 0<d<1; delta comparisons are exact rational.")

    tstar = rif(fa**2/delta**2)
    pstar = (-tstar).exp()/rif(delta**2)
    qstar = (1-(-tstar).exp())/(2*rif(fa**2))
    hstar = 1+16*rif(fa**2)/ra2
    # Choose the min by disjoint certified enclosures, not machine float.
    assert pstar.upper().exact_rational() < qstar.lower().exact_rational()
    cn = pstar/hstar**2
    mu_n = (-tstar/2).exp()/rif(fa)
    mu_s = -rif(3).sqrt()               # cot(5*pi/6)
    cb = ra2/(ra2+4*rif(fa**2))*(mu_n-mu_s)
    assert cn.lower().exact_rational() > 0
    assert cb.lower().exact_rational() > 0
    certificates["north_witness_lower_bounds"] = {
        "T_star": endpoints(tstar), "p_star": endpoints(pstar),
        "q_star": endpoints(qstar), "H_star": endpoints(hstar),
        "c_N": endpoints(cn), "mu_N": endpoints(mu_n),
        "mu_S": endpoints(mu_s), "c_B": endpoints(cb),
        "scope": "Positive scalar bounds for the northern-only witness. Neither c_S nor a closed smooth sphere metric is certified here.",
    }
    passed("I06", "The witness gives strictly positive certified scalar c_N and c_B.",
           "Exact rational lower endpoints of both outward-rounded intervals are positive; no underflow or floating-point sign test.")

    limitations = [
        "This module certifies specified scalar inequalities, not every plane of an actual metric by interval subdivision.",
        "Global x>0 control uses the stated analytic positive-series tails in addition to the finite interval domain.",
        "The independent standard-library checker cannot recompute exp, sinh or sqrt; interval output is replayed only by rerunning Sage/MPFI/MPFR.",
        "Smooth cutoff existence, ODE inverse existence, geometric reduction to scalar bounds, and the southern and gluing theorems remain analytic dependencies.",
        "The witness is not a closed-manifold metric and does not select a valid southern connection or A0 for any smooth sphere type.",
    ]
    return {"checks": checks, "certificates": certificates, "limitations": limitations}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
