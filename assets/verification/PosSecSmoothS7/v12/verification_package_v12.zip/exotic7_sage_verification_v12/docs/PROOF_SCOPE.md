# v12 proof map, mathematical audit, and computational scope

Input: the unchanged `v12_clean.tex`, SHA-256
`ea27de068cd78871211d0a1ac102e76b65c7bd1f033267fb24a2c5f8dc423f9e`.
This version was reread and its checks executed anew on 2026-09-25.
`source_binding.py` freezes source identity and 80 labeled display blocks;
this identity check is not itself mathematical verification.

The actual reference run records **80 PASS, 0 FAIL, 7 UNVERIFIED** groups,
**48** independently replayed rational certificates, and **33** rejected
mutated expression certificates. The 80 display blocks contain 92 labels;
display-block and check-group counts are not the same kind of evidence.

The exact target of the supplied manuscript is

\[
 \forall[\Sigma]\in\Theta_7\quad
 \exists g\in\operatorname{Met}^{\infty}(\Sigma)\quad
 \exists c_\Sigma>0\quad
 \forall p\in\Sigma\ \forall\Pi\in\operatorname{Gr}_2(T_p\Sigma),
 \qquad \sec_g(\Pi)\ge c_\Sigma.
\]

This package checks the computational content used in the proposed proof. It
does not encode this entire quantified statement and its proof in a formal
proof assistant. It supplies exact Sage calculations, separately replayable
rational certificates, and the following human audit of their interfaces.

## Section 2: marked models and all-28 coverage

`topology.py` checks generic quaternion multiplication, norm multiplicativity,
the denominator-cleared invariance of `u^{-1}xu`, and the infinitesimal
conjugation norm. The Blakers--Massey scalar factor's two limiting values are
computed symbolically. These support the component calculations in the text.

The all-orders smoothness argument remains analytic. Near s=0, sin(pi sqrt(s))/
sqrt(s) and cos(pi sqrt(s)) have convergent power series in integer powers of s.
Near s=1, sqrt(s) is smooth and the numerator has a simple zero, so division by
1-s extends smoothly (for example by the integral form of Hadamard's lemma).
This establishes smoothness, not merely continuity of the two limits.

Equivariance implies b(b(x)^{-1}xb(x))=b(x). The inverse map is
b(x)xb(x)^{-1}; iteration gives sigma^n(x)=b(x)^{-n}xb(x)^n for every integer
n. This general induction, not a test of 28 sample quaternions, is the needed
attaching-map statement.

The star action is free since qu=u implies q=1. Every star orbit in a product
disk has a unique representative (Y,1), with Y=u^{-1}zu. The explicit inverse
Y -> [(Y,1)] establishes the disk identification. Transition u_S=g_n(x)u_N
then gives y_S=g_n(y_N)^{-1}y_Ng_n(y_N). Compatible signed collar coordinates
make this identification smooth across the seam. These are human geometric
arguments, not numerical assertions about a mesh.

The theorem identifying this attaching map with n mod 28 is an external
dependency: Durán--Püttmann--Rigas, Theorem 1 and its proof in Section 4.
The original text explicitly gives the same sigma and its iterates:
https://arxiv.org/html/math/0610349v1#S4 . The correspondence of the supplied
formula with that text was checked during this audit. The script's enumeration
of 28 residues verifies bookkeeping only; it does not reprove the classification.

Forgetting the star action leaves a principal bundle classified modulo 12.
An isomorphism of that principal bundle need not preserve the star action, so
there is no inference identifying the star quotients modulo 12.

## Sections 3 and 4: full connection curvature and the southern disk

`connection.py` builds Levi--Civita coefficients from the non-coordinate frame
brackets using Koszul's formula. It then differentiates them and computes
R(A,B)C = nabla_A nabla_B C - nabla_B nabla_A C - nabla_[A,B] C.
The model has all seven horizontal and three vertical indices. It checks 5,176
component comparisons and a separate 45-component quaternion action-sign check.
The horizontal base curvature is retained as a separate input; no flat-base
hypothesis is inserted into the proposition.

For a decomposable bivector, the exact checks establish the Plücker identity,
the coefficient -3/2 of the Lie-bracket coupling, and the decomposition of its
norm into horizontal, mixed, and vertical squares. Generic symbolic plane
variables range over all values; this is not a finite plane sample. The norm
inequalities use Cauchy--Schwarz kernels, the declared ordered-index norms,
and triangle inequalities. Their use as inequalities is documented in the
connection audit. The scalar C=4 estimate and Young losses are then checked.

The final estimate is

\[
 \mathcal K_{G_\varepsilon}(\xi)
 \ge \frac\kappa2 h^2+\frac{\varepsilon\Lambda}{8}m^2
        +\frac1{8\varepsilon}k^2.
\]

All coefficients are positive for a fixed admissible epsilon, and the norm
identity h^2+m^2+k^2=|xi|^2 yields a uniform lower bound on unit decomposable
bivectors. The code checks the identities and scalar budgets; the geometric
identification of the frame, the base sectional lower bound and the Hessian
inequality remain the stated hypotheses.

The specific southern connection has A_N=chi g_n^{-1}dg_n and
A_S=(chi-1)dg_n g_n^{-1}. Substitution yields exactly
A_N=g_n^{-1}A_Sg_n+g_n^{-1}dg_n, the transition rule for this P_n. In the
extending south gauge the connection is zero near the pole. Its curvature and
covariant derivative are therefore smooth on a compact disk and have finite
suprema. No explicit values of these n-dependent suprema are required by the
existence argument, and none have been fabricated by the package.

Under the star action A transforms by conjugation and u -> qu, so
u^{-1}Au+u^{-1}du is invariant. The height function phi=-A0 cos(t) satisfies
-Hess(phi)=-A0 cos(t) g_B >= A0 |cos(a)| g_B. The script checks its two radial
Hessian eigenvalues, radius derivatives, pole values, and boundary slopes.
Evenness at the pole and smoothness of the round polar metric supply the
all-orders smooth extension in the human proof.

O'Neill's formula transfers the positive lower bound from the source to the
free quotient. This standard geometric theorem, smooth quotient construction,
and compactness reasoning are not reproved by finite Sage calculations.

## Section 5: the northern disk and all moving two-planes

`north.py` independently reconstructs the warped metric's curvature from its
metric two-jet in the full ten-dimensional source: one radial, six angular and
three fibre directions. All 45 diagonal curvature-operator entries match the
five block formulas; all 1,980 off-diagonal entries vanish exactly.

It also checks the generic horizontal graph, the quotient differential,
the cometric, and the area identities. The graph projection is injective. Thus
an independent horizontal pair has a nonzero combined projected base area.
This is why strict radial and angular coefficients control every horizontal
two-plane, including planes varying with epsilon and lower-rank orbit points.

The function F is the inverse of the smooth strictly increasing function
J(F)=integral_0^F exp(z^2/(2 delta^2)) dz. Consequently it is globally smooth
on the finite chosen interval and has the required odd smooth extension at
zero. A finite Taylor jet test supports, but does not replace, this inverse
function argument. A smooth cutoff eta with the stated support properties
exists, and r is then a genuine smooth function, constant near the center.

The angular inequality uses the positive-term series of sinh and an exact
minimum certificate. The radial loss is supported only where F<=delta/2.
The code checks the polynomial identities and all scalar margins. Elementary
exponential monotonicity and positivity of omitted series terms are human
analysis. The graph norm gives the square H_*^2 on exterior powers, yielding
the printed uniform quotient bound c_N>0.

## Common epsilon and ordering of parameters

`parameter_logic.py` provides explicit symbolic upper bounds with denominators
1+nonnegative terms, so vanishing curvature or derivative bounds do not cause
division by zero. Their minimum is positive for every fixed finite choice of
geometric data. These bounds imply all the southern and northern smallness
conditions, as shown by rational slack identities and epsilon^3<=epsilon.

The order is n, then a/b0/chi and their finite M0/M1, then Lambda/A0, then
eta/delta/F/ell_N, and finally epsilon. The length can be large but is finite
and independent of epsilon. The proof needs a separate epsilon for each type,
not a single numerical epsilon uniformly across all clutching powers.

## Section 6: boundary compatibility

Both boundary source metrics are the same product in the common north gauge,
and the star actions agree. The identity in that gauge is the map sigma^n in
the extending disk markings. This proves that the metric equality is under
the required attaching map; it is not an assumption that sigma^n preserves a
separately fixed round metric.

On common horizontal lifts, the fibre shape contributions cancel. The remaining
sum is (mu_N-mu_S)|X|^2, and the horizontal graph implies X is nonzero for every
nonzero quotient tangent vector. The eigenvalue and margin identities are
checked exactly. Their uniform lower bound is the stated c_B>0, with both
outward normals and the metric normalization accounted for.

## Appendix B: interpolation and smoothing

`gluing.py` checks the Hermite interpolant, endpoint jets, derivative formulas,
formal remainder orders, all curvature blocks, determinant interpolation,
and the mixed-angle Young square. Its general coordinate-jet test runs in
the actual ambient dimension seven. Its 3,966 exact residual comparisons
include 2,401 coordinate curvature entries, 1,296 Gauss entries, 216 Codazzi
entries, 36 radial entries, and 17 interpolation and scalar identities. This
finite generic calculation still does not
formalize the dimension-independent tensor argument or smooth analysis.

Uniform C^j bounds follow from fixed smooth compact collars and the explicit
interpolation. The positive shape jump gives radial curvature of order 1/tau;
the Codazzi block stays bounded. The complete angle inequality absorbs this
block uniformly. This handles every plane, rather than only radial and tangent
planes separately.

At each interface the first derivatives agree. Therefore weak second derivatives
have no Dirac term. Tensor-valued convolution uses the same nonnegative kernel
on the fixed product bundle. The all-lowered curvature is linear in second
derivatives plus a smooth function of the metric and first derivatives. The
nonlinear error tends uniformly to zero by C^1 convergence and compactness.
The common product identification preserves decomposability; hence averaging
the all-plane lower bound and controlling the error preserves strict positivity.
Localization occurs on a fixed smooth transition strip where C^2 convergence
holds. The order is fixed epsilon, then fixed tau, then small nu. No shrinking-
collar derivative loss has been silently discarded.

These analytic convergence arguments were read and reviewed. They are explicitly
UNVERIFIED by the finite computational scripts, which do not constitute a
formalization of smooth analysis.

The external Reiser--Wraith Theorem A(i), k=1, gives smooth positive-sectional-
curvature gluing with the stated boundary convention. Corollary B also preserves
an arbitrary strict lower bound, validating the use of half the smaller input
bound in the manuscript. The precise source was checked:
https://arxiv.org/html/2308.06996v2 . The appendix supplies the strict positivity
case; the sharper final half-minimum choice additionally cites Corollary B.

## What the aggregate result means

No algebraic counterexample or substantive defect was found in the implemented
computations and the scoped human review. The package makes the computational
parts independently inspectable and replayable. It does not certify arbitrary
future edits of the paper, prove a theorem merely by listing 28 residues, or
establish the external theorems from foundational axioms. Source correspondence,
analytic arguments and theorem application remain open to expert scrutiny.

## Rigorous scalar intervals added for v12

`interval_bounds.py` uses 200-bit Sage RealIntervalField with directed outward
rounding. It checks 224 closed rational cells covering [1/2,4] for
R(x)=2 sinh(x^2/2)/x^3, exporting every input interval and every enclosure as
exact rational endpoints. Every enclosure has lower endpoint greater than 1/2.
The tails use the human positive-series inequality R(x)>=1/x+x^3/24, with
exact endpoint comparisons. This is not an interval scan of all manifold
points and tangent planes. Additional interval witnesses check scalar reserves
and a northern-only parameter example; no southern admissibility or closed
metric is asserted for that example.

The standard-library checker verifies only the labeled rational polynomial
certificates. Recomputing transcendental intervals requires Sage/MPFI/MPFR;
the independent checker does not claim to re-prove exp or sinh enclosures.

The all-28 target and every theorem statement are preserved. A complete Lean
formalization would be a separate project requiring precise definitions and
proofs of the remaining global geometric and analytic dependencies.
