# v12 claim-by-claim correspondence

This table covers all nine named theorem, proposition, and lemma statements in
the supplied manuscript. Labels identify the exact statement in both TeX files;
source line numbers and the complete label inventory are in
`certificates/document.json`. Theorem statements were not altered.

"Supports" means the stated computational content was checked. It does not
mean the named geometric statement has been completely machine-proved.
The v12 run has 80 PASS and seven UNVERIFIED groups; 48 rational certificates
replay, and all 33 deliberately altered expression certificates are rejected.

| Manuscript statement | Supporting executed checks | Essential noncomputational dependencies |
|---|---|---|
| Main theorem (`thm:main`) | All modules, together with the parameter intersection `P01`-`P05` | All preceding geometric implications; identification with every class in Theta_7; existence and smoothness of the quotients and smoothing |
| Compatible positive disk metrics (`thm:fillings`) | `connection.*`, `south.*`, `N01`-`N12`, `P01`-`P05` | Smooth global marked disks, submersion theorem, compactness, the correspondence between the common boundary gauge and the attaching map |
| The attaching map (`lem:topology`) | `T01`-`T11` | All-orders endpoint smoothness; equivariance and iteration; global disk trivializations; Durán--Püttmann--Rigas Theorem 1 for the subsequent smooth-type classification |
| Positive connection metrics (`prop:concave`) | `connection.right_action_sign` through `connection.radius_chain_rule`; `P01`-`P05` | Smooth connection/frame realization; the base sectional bound and Hessian hypothesis; finite suprema on the compact base; tensor/norm arguments as stated |
| Southern filling (`thm:southfilling`) | Connection checks and `south.radius_derivatives`, `south.pole_and_boundary`, `south.connection_curvature`, `south.noncommutative_gauge` | Smooth cutoff and clutching connection; pole extension; invariant free action; O'Neill descent |
| Northern filling (`thm:northfilling`) | `N01`-`N10`, `N12`, `P01`-`P05` | Inverse-function construction on the whole interval; cutoff and polar smoothness; submersion; compactness; the southern input constants |
| Horizontal curvature criterion (`lem:northcriterion`) | `N01`-`N04`, `N07`-`N08`, `N12` | Dimension-independent tensor interpretation and exterior-power norm argument; geometric realization of the star-horizontal distribution |
| Boundary compatibility (`prop:boundarycompatibility`) | `T03`-`T06`, `T09`-`T11`, `N02`, `N11`, `south.pole_and_boundary` | Identity in common gauge is sigma^n in the extending markings; equality of the complete boundary source metrics and actions |
| Positive gluing (`lem:gluing`, alias `thm:RW`) | All `gluing.*` PASS checks | Uniform collar estimates; weak second derivatives; convolution and localized smoothing; Section 6's quantitative bound also uses Reiser--Wraith Corollary B |

## Dependency order and quantifiers

The source hash and 80 labeled display blocks are bound by `S01`-`S03`.
`I01`-`I06` additionally support specified scalar bounds using genuine directed
rounding and explicitly analytic tails. They do not interval-certify the entire
geometric theorem or give a valid southern witness for every n.

1. Fix an arbitrary integer n, not a numerically tested clutching sample.
2. Identify the marked quotient and its attaching map sigma^n.
3. Fix smooth southern data and their finite n-dependent bounds.
4. Fix the northern profile and its finite length independently of epsilon.
5. Choose epsilon below the finite minimum of positive thresholds. The exact
   rational slack identities are in `parameter_logic.json`.
6. Obtain uniform positive lower bounds on **all** two-planes of both disks.
7. Identify the boundaries by the prescribed attaching map and verify the
   strictly positive sum of second fundamental forms.
8. Glue and smooth with fixed input metrics; choose the smoothing scales only
   after fixing epsilon.
9. Apply the external classification for n modulo 28.

The polynomial calculations use generic variables, not representative samples
of the 28 types. Conversely, the residue enumeration does not prove a geometric
existence theorem. Both distinctions matter.

## The seven explicit UNVERIFIED entries

These are seven reported *dependency groups*, not necessarily seven missing
proofs in the manuscript, and not an exhaustive count of every analytic fact.

- `south.external_geometry`: marked disks, free action, submersion descent.
- `N13`: northern global analytic and topological hypotheses.
- `gluing.analytic.uniformity`: uniform estimates and compact plane bundles.
- `gluing.analytic.smoothing`: tensor convolution and localized smoothing.
- `gluing.application.input_metrics`: the globally valid disk metrics needed
  by the gluing theorem.
- `gluing.external.quantitative_bound`: the external quantitative gluing result.
- `P06`: finiteness of geometric bounds and elementary analytic implications.

Their human proof routes are discussed in `PROOF_SCOPE.md` and the four scoped
audit notes (topology, connection, north, and gluing). No module silently converts
these entries to PASS.
