# Public description and evidentiary scope

This document concerns how to describe the v12 verification companion
accurately. It does not issue journal acceptance, an external referee
certification, or a formal proof of the paper.

## Suggested short English description

> This version-bound verification companion contains executed SageMath
> computations, replayable exact rational polynomial certificates, rigorous
> scalar interval enclosures, and complete reference-run records. It checks
> specified local curvature identities, parameter estimates and gluing
> algebra, with mathematical assumptions and non-formalized dependencies
> explicitly documented. It is not an end-to-end formal machine proof of
> the theorem on all 28 oriented smooth seven-sphere types.

## 建议使用的简短中文说明

> 本验证材料与 v12 论文的具体源版本绑定，包含实际执行的 SageMath
> 计算、可独立重放的精确有理多项式证书、严格标量区间包络及完整运行
> 记录。它核验指定的局部曲率恒等式、参数估计和粘合代数，并明确保留
> 数学假设与尚未形式化的依赖；它不是关于全部二十八种有向光滑七维
> 球面主定理的全链机器形式化证明。

## What a PASS badge means

PASS refers to implemented checks in the archived run and listed certificate
replays. Authoritative counts are in reproduction/reference-run/summary.json;
VERIFICATION_REPORT.md summarizes them. A PASS group need not be a theorem,
and its count does not measure the fraction of the main theorem proved.

The polynomial checker independently recomputes claims explicitly encoded
under replayable. It does not recompute every tensor derivation,
transcendental interval enclosure, or analytic argument. Independence from
Sage narrows the software trust chain for these claims; it does not remove
trust in software or in faithful translation of the manuscript.

Intervals cover specified scalar domains, with unbounded portions closed
by stated analytic tail bounds. They do not subdivide all tangent planes
of a closed sphere. The explicit parameter witness is northern-only and
must not be advertised as a complete positive metric on an exotic sphere.

## How to present dependencies

Use three separate labels where appropriate:

- **Computed:** the precise identity, bounded domain or data comparison
  actually executed by a named check.
- **Mathematically reviewed:** the stated human argument was examined with
  its assumptions and scope identified. No detected error is not a proof
  that no error exists.
- **External theorem:** the cited result and its applicability were checked;
  its proof is not supplied by the Sage run.

UNVERIFIED means not established by this finite computational test. It
need not mean false or missing from the human paper. Conversely, it must
not silently become PASS because surrounding modules passed.

## Statements to avoid

- “Sage proves all 28 smooth seven-spheres have positive curvature.”
- “The entire paper is machine verified.”
- “The package is a Lean proof.”
- “All errors have been ruled out.”
- “The interval checker covers every point and plane of the final metric.”
- “A source hash proves the mathematical statements are correct.”
- “A northern parameter witness provides the whole closed-sphere construction.”

None of these conclusions follows from this package.

## Versioning and updates

Publish the source SHA-256, package version, code and certificates together.
Keep the claim mapping and non-formalized-dependency list near the results,
not hidden in a download. An attractive website may simplify navigation
but must not strengthen the claims.

After a formula, assumption or input source changes, bind a new reviewed
source contract and rerun affected checks. Preserve the old release and
explain changes. If an error is found, distinguish its effect on the
checker, a local lemma, or the main theorem; do not silently replace
historical evidence.

No public hosting or publication is performed by preparing these files.
