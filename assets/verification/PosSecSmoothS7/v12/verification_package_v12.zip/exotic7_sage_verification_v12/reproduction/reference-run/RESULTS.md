# Reproduction result

Computational checks: **PASS**.

Complete geometric theorem: **not formally machine certified by this package**.

SageMath 10.9; started 2026-09-25T13:34:42.305207+00:00.

| Check | Status | Claim |
|---|---|---|
| S01 | PASS | The submitted source is exactly the reviewed v12 file, not a previous manuscript |
| S02 | PASS | Every inventoried labeled display matches the separately frozen source contract |
| S03 | PASS | This v12 release does not silently change the supplied manuscript |
| T01 | PASS | Quaternion multiplication is associative |
| T02 | PASS | Quaternion norm is multiplicative and conjugation reverses products |
| T03 | PASS | The quotient coordinate u^{-1} x u is invariant under (x,u)->(q x q^{-1},qu) |
| T04 | PASS | Bundle transition and right principal action commute |
| T09 | PASS | The marked transition is conjugation by g_n(y), after imposing the equivariance premise |
| T10 | PASS | Opposite conjugations are inverse when the conjugating quaternion is unit |
| T11 | PASS | The induction step for iterated conjugation has the required multiplication order |
| T05 | PASS | K^* K = 4((\|p\|^2+\|Im w\|^2)I-p p^T-Im(w) Im(w)^T) |
| T06 | PASS | On \|x\|=1, \|\|K_x v\|\|^2 <= 4\|\|v\|\|^2, including all orbit ranks |
| T07 | PASS | Blakers--Massey scalar factor has endpoint limits pi and pi/2 |
| T08 | PASS | Residues 0,...,27 give 28 labels and orientation reversal gives 15 orbits |
| connection.v12_source_binding | PASS | Audited connection formulas are bound to the submitted v12 source |
| connection.right_action_sign | PASS | Quaternion vector fields independently confirm bracket and equivariance signs |
| connection.koszul | PASS | Koszul reconstruction agrees with Koszul formula |
| connection.hvhv | PASS | Koszul reconstruction agrees with HVHV formula |
| connection.hhvv | PASS | Koszul reconstruction agrees with HHVV formula |
| connection.hvvv | PASS | Koszul reconstruction agrees with HVVV formula |
| connection.hhhv | PASS | Koszul reconstruction agrees with HHHV formula |
| connection.hhhh | PASS | Koszul reconstruction agrees with HHHH formula |
| connection.vvvv | PASS | Koszul reconstruction agrees with VVVV formula |
| connection.curvature_sign_negative_control | PASS | A deliberately reversed HVHV bracket sign is rejected |
| connection.plucker | PASS | The printed Pluecker identity has the correct sign |
| connection.bracket_contraction | PASS | Linear curvature terms sum to -3 J/2 |
| connection.horizontal_section | PASS | Derived horizontal correction contracts to -3 r^2 \|Omega(X,Y)\|^2/4 |
| connection.bivector_norm | PASS | h^2+m^2+k^2=\|(X+U) wedge (Y+V)\|^2 |
| connection.quaternion_bracket_norm | PASS | The SU(2) bracket bound is an exact norm identity |
| connection.norm_kernels | PASS | Cauchy--Schwarz and the fibre dimension-three array factor are exact |
| connection.common_constant | PASS | C=4 dominates every sharp-master loss |
| connection.young_identity | PASS | Every absorption uses a certified nonnegative square |
| connection.reserve_arithmetic | PASS | The written losses leave at least the claimed reserve |
| connection.young_coefficients | PASS | All three printed Young coefficients are sufficient |
| connection.smallness_implications | PASS | Each smallness hypothesis supplies its assigned loss budget |
| connection.radius_chain_rule | PASS | Differentiating r=sqrt(eps) exp(eps phi/2) gives the claimed Hessian tensor |
| south.radius_derivatives | PASS | Southern r, logarithmic slope and Hessian have the printed signs |
| south.pole_and_boundary | PASS | Pole parity, mixed pole coefficient, boundary form and slope scaling agree |
| south.connection_curvature | PASS | Maurer--Cartan gives the stated cutoff curvature |
| south.noncommutative_gauge | PASS | Quaternion multiplication verifies the southern gauge transformation |
| south.external_geometry | UNVERIFIED | Global marked-disk identification, action freeness, and O'Neill descent are external to this symbolic module |
| N01 | PASS | The infinitesimal conjugation map is tangent and \|\|K_x\|\| <= 2. |
| N02 | PASS | The star-horizontal graph and boundary cometric have the stated factors and signs. |
| N03 | PASS | Both area estimates are valid, including the mixed-area factor 8. |
| N04 | PASS | The complete doubly warped curvature operator has exactly the five claimed blocks. |
| N05 | PASS | The profile derivatives, curvature coefficients and center Taylor jet are correct. |
| N06 | PASS | The global elementary lower bound is valid for every x>0. |
| N07 | PASS | The radial criterion and the claimed uniform P bound follow with strict reserve. |
| N08 | PASS | The angular curvature criterion holds uniformly and leaves at least half the angular coefficient. |
| N09 | PASS | The small-parameter northern inequalities and matching boundary data coexist. |
| N10 | PASS | There is an explicit exact witness for the northern parameter inequalities. |
| N11 | PASS | The outward shape terms cancel exactly in the fibre directions; the stated boundary margin is positive and sharp. |
| N12 | PASS | The announced positive quotient lower bound follows from the verified coefficients. |
| N13 | UNVERIFIED | Global analytic/topological hypotheses needed to turn the exact north certificates into a complete filling and gluing theorem. |
| gluing.hermite.endpoint_jets | PASS | Cubic interpolant matches values and first normal derivatives at both interfaces. |
| gluing.hermite.derivatives | PASS | Displayed first and second derivatives are exact. |
| gluing.hermite.formal_orders | PASS | Finite Taylor jets have the claimed scaled leading orders H=h+O(t), H'=((1-y)P+(1+y)Q)/2+O(t), H''=-(P-Q)/(2t)+O(1). |
| gluing.determinant | PASS | The 2-by-2 determinant interpolation identity has the sign stated in the manuscript. |
| gluing.tangential_gain | PASS | Subtracting the interpolated determinant gives the nonnegative tangential correction +l(1-l) det(P-Q)/4 when 0<=l<=1 and P-Q is positive definite. |
| gluing.curvature.coordinate_formula | PASS | The displayed all-lowered coordinate curvature formula has the correct convention and separates linear second derivatives from nonlinear first derivatives. |
| gluing.curvature.radial | PASS | Radial block equals -H''/2+H' H^{-1} H'/4. |
| gluing.curvature.gauss | PASS | Tangential Gauss block has the sign that yields K_G=K_H-det(H'\|Pi)/(4 det(H\|Pi)). |
| gluing.curvature.codazzi | PASS | Mixed curvature block equals ((D_j H')_ik-(D_i H')_jk)/2 and contains no H''. |
| gluing.mixed.schur | PASS | The all-plane lower bound follows by an exact nonnegative square, including angles depending on tau. |
| gluing.interface.distributional_jump_coefficients | PASS | Jump coefficients of the metric and first derivative vanish at both interfaces. |
| gluing.analytic.uniformity | UNVERIFIED | Uniform C_X^j estimates, positivity for sufficiently small tau, and compact minima on all plane bundles. |
| gluing.analytic.smoothing | UNVERIFIED | Common tensor convolution and localized smoothing preserve positive sectional curvature. |
| gluing.application.input_metrics | UNVERIFIED | The particular disk metrics satisfy the global positive sectional-curvature and strictly positive boundary-jump hypotheses. |
| gluing.external.quantitative_bound | UNVERIFIED | Section 6 obtains K>min(c_S,c_N)/2 from Reiser-Wraith Corollary B. |
| P01 | PASS | A/(B(1+x)) gives slack A/(1+x) in A-B*epsilon*x at the threshold |
| P02 | PASS | For 0<=epsilon<=1, epsilon^3<=epsilon |
| P03 | PASS | Every displayed scalar upper bound satisfies its corresponding linear constraint |
| P04 | PASS | Northern d<1 follows with a fixed strict reserve from the chosen thresholds |
| P05 | PASS | The allocated mixed-loss budget leaves exactly epsilon Lambda/8 |
| P06 | UNVERIFIED | The concrete n-dependent curvature suprema and smooth cutoff derivative bounds are finite, and all interval/exponential monotonicity hypotheses apply |
| I01 | PASS | The rational cells cover [1/2,4] without a gap. |
| I02 | PASS | The elementary ratio is greater than 1/2 on every point of [1/2,4]. |
| I03 | PASS | Exact endpoint comparisons close the small and large tails, conditional on the positive sinh-series bound. |
| I04 | PASS | The stated strict exponential and fourth-root reserves have rigorous interval separation. |
| I05 | PASS | The concrete northern-only parameter witness obeys both epsilon conditions. |
| I06 | PASS | The witness gives strictly positive certified scalar c_N and c_B. |
| D01 | PASS | Revised LaTeX labels are unique |
| D02 | PASS | All ref/eqref/hyperref targets exist |
| D03 | PASS | All citation keys have bibliography entries |
| D04 | PASS | All nine theorem, lemma and proposition statements agree byte-for-byte with the supplied v12 |
| independent_exact_replay | PASS | The standard-library-only checker accepts all exported supported certificates |
| incorrect_certificates_rejected | PASS | Adding 1 to the right side of each unexpanded identity is detected |

UNVERIFIED denotes a claim not established by the finite computational test; see docs/PROOF_SCOPE.md for its human/external proof route.
