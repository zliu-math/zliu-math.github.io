#!/usr/bin/env python3
"""Prepare release evidence from an unchanged reference Sage run.

Run with --python /path/to/non-sage/python3. This helper checks source/code
hashes, copies archived certificate JSON, runs the small checker in that
separate Python, and generates VERIFICATION_REPORT.md. It does not run or
change the Sage checks, manuscript, or reference-run.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "reproduction/reference-run"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8")


def prepare(non_sage_python):
    summary = load(REFERENCE / "summary.json")
    environment = load(REFERENCE / "environment.json")
    bindings = {
        "paper/submitted.tex": summary["source_sha256"],
        "paper/revised.tex": summary["revised_sha256"],
        **environment["checked_code_sha256"],
        **environment["support_code_sha256"],
    }
    for relative, expected in bindings.items():
        if sha256(ROOT / relative) != expected:
            raise RuntimeError(f"Reference-run hash mismatch: {relative}")
    counts = dict(Counter(c["status"] for c in summary["checks"]))
    if counts != summary["counts"]:
        raise RuntimeError("Reference summary counts do not match its checks")
    if (summary["computation_status"] != "PASS" or counts.get("FAIL", 0)
            or summary["failed_checks"]):
        raise RuntimeError("The reference run is not a computational PASS")

    files = sorted((REFERENCE / "certificates").glob("*.json"))
    if not files:
        raise RuntimeError("No reference certificate files")
    target_dir = ROOT / "certificates"
    target_dir.mkdir(parents=True, exist_ok=True)
    unexpected = {p.name for p in target_dir.glob("*.json")} - {p.name for p in files}
    if unexpected:
        raise RuntimeError("Refusing stale certificates: " + ", ".join(sorted(unexpected)))
    copied, kinds = [], Counter()
    total = 0
    for source in files:
        target = target_dir / source.name
        shutil.copyfile(source, target)
        if source.read_bytes() != target.read_bytes():
            raise RuntimeError("Certificate copy mismatch: " + source.name)
        rows = load(source).get("replayable", [])
        total += len(rows)
        kinds.update(row["kind"] for row in rows)
        copied.append({"path": str(target.relative_to(ROOT)),
                       "sha256": sha256(target), "replayable_items": len(rows)})
    if not total:
        raise RuntimeError("No replayable certificates")

    # Probe the actual separate interpreter, not merely a script's imports.
    # Isolated mode excludes user-site packages and the current directory.
    probe_code = (
        "import importlib.util,json,platform,sys;"
        "print(json.dumps({'version':sys.version,"
        "'implementation':platform.python_implementation(),"
        "'machine':platform.machine(),'platform':platform.platform(),"
        "'isolated_mode':bool(sys.flags.isolated),"
        "'sage_discoverable':importlib.util.find_spec('sage') is not None}))")
    probe = subprocess.run([non_sage_python, "-I", "-c", probe_code],
                           cwd=ROOT, capture_output=True, text=True, check=True)
    runtime = json.loads(probe.stdout)
    if runtime["sage_discoverable"]:
        raise RuntimeError("Select a Python in which Sage is not discoverable")

    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    replay = subprocess.run(
        [non_sage_python, "-I", "verify_certificates.py", "certificates"],
        cwd=ROOT, capture_output=True, text=True, check=False)
    elapsed = time.monotonic() - clock
    prefix = ROOT / "reproduction/independent-replay"
    stdout_path = Path(str(prefix) + ".stdout.log")
    stderr_path = Path(str(prefix) + ".stderr.log")
    stdout_path.write_text(replay.stdout, encoding="utf-8")
    stderr_path.write_text(replay.stderr, encoding="utf-8")
    try:
        result = json.loads(replay.stdout.strip().splitlines()[-1])
    except (json.JSONDecodeError, IndexError):
        result = {"error": "Checker emitted no valid final JSON summary"}
    status = ("PASS" if replay.returncode == 0 and result.get("checked") == total
              and result.get("failures") == [] else "FAIL")
    record = {
        "status": status, "started_utc": started,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": round(elapsed, 6), "returncode": replay.returncode,
        "command_template": ["NON_SAGE_PYTHON", "-I", "verify_certificates.py",
                             "certificates"],
        "runtime": runtime, "checker_sha256": sha256(ROOT / "verify_certificates.py"),
        "source_sha256": summary["source_sha256"],
        "reference_summary_sha256": sha256(REFERENCE / "summary.json"),
        "reference_environment_sha256": sha256(REFERENCE / "environment.json"),
        "checked_source_and_code_bindings": bindings, "certificate_files": copied,
        "certificate_kind_counts": dict(kinds), "expected_replayable_count": total,
        "checker_result": result, "stdout_sha256": sha256(stdout_path),
        "stderr_sha256": sha256(stderr_path),
        "scope": ("Independent standard-library replay of encoded rational "
                  "polynomial claims only. It does not rerun symbolic tensor "
                  "derivations or transcendental interval enclosures, certify "
                  "manuscript translation, or formally prove the complete "
                  "all-28 smooth-existence theorem."),
    }
    write_json(Path(str(prefix) + ".json"), record)
    if status != "PASS":
        raise RuntimeError("Independent replay failed; see its logs")

    mutations = next(c for c in summary["checks"]
                     if c["id"] == "incorrect_certificates_rejected")["evidence"]
    unverified = [c for c in summary["checks"] if c["status"] == "UNVERIFIED"]
    lines = [
        "# Verification report — v12", "", "## Outcome", "",
        f"The archived SageMath {environment['sage_version']} run reports "
        f"**{counts.get('PASS',0)} PASS groups, {counts.get('FAIL',0)} FAIL groups, "
        f"and {counts.get('UNVERIFIED',0)} explicitly UNVERIFIED-by-computation "
        "dependency groups**.", "",
        f"**{total} exact rational polynomial certificates** were accepted "
        "by a separate standard-library-only Python interpreter "
        f"({runtime['implementation']} {runtime['version'].split()[0]}). "
        "The runtime probe found no importable Sage installation. All "
        f"**{mutations['mutations_tested']}** right-side-plus-one expression "
        "mutations were rejected in the reference run. The connection module "
        "also includes a separately identified wrong-sign negative control.", "",
        "**The complete geometric existence theorem is not formally machine "
        "certified by this package.** PASS concerns implemented checks and "
        "their assumptions, not every global argument in the paper. UNVERIFIED "
        "means not established by these finite computational tests; it does "
        "not mean that the mathematical statement is false.", "",
        "## Exact input and execution", "",
        "- Manuscript: paper/submitted.tex, the submitted v12_clean.tex.",
        "- Source SHA-256:", "", "    " + summary["source_sha256"], "",
        "- Revised-source SHA-256: " + summary["revised_sha256"],
        "- The submitted and revised sources are byte-identical in this release.",
        "- Reference started: " + summary["started_utc"],
        "- Reference finished: " + summary["finished_utc"],
        f"- Reference elapsed time: {summary['elapsed_seconds']} seconds "
        "(machine-dependent, not a correctness criterion).",
        "- Reference Python: " + environment["python_version"],
        "- Reference platform: " + environment["platform"],
        "- The release helper checked archived hashes of all executed modules "
        "and recorded support files before preparing this report.", "",
        "## Module counts", "",
        "These are check groups, not independent theorems or tensor-component counts.",
        "", "| Module | PASS | FAIL | UNVERIFIED | Reference seconds |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for run in summary["runs"]:
        mc = run["counts"]
        lines.append(f"| {run['module']} | {mc.get('PASS',0)} | "
                     f"{mc.get('FAIL',0)} | {mc.get('UNVERIFIED',0)} | "
                     f"{run['elapsed_seconds']} |")
    rc = Counter(c["status"] for c in summary["checks"]
                 if c["module"] == "certificate_replay")
    lines.append(f"| replay and mutation controls | {rc.get('PASS',0)} | "
                 f"{rc.get('FAIL',0)} | {rc.get('UNVERIFIED',0)} | in total |")
    lines += [
        "", "## What was computed", "",
        "- Source binding: exact hash, frozen labeled-display inventory, and "
        "preservation of the supplied manuscript.",
        "- Quaternionic topology algebra: generic quaternion identities, "
        "marked-transition algebra, action norm bound and label bookkeeping. "
        "The smooth classification remains an external mathematical input.",
        "- Connection geometry: independent Koszul/curvature reconstruction "
        "for a seven-dimensional base and three-dimensional fibre, including "
        "5,176 tensor/connection comparisons, quaternion sign checks, "
        "decomposability relations, mixed contractions and absorption identities.",
        "- Northern geometry: complete ten-dimensional doubly warped source "
        "reconstruction, with 45 diagonal and 1,980 off-diagonal bivector "
        "matrix entries, plus graph, profile and boundary identities.",
        "- Gluing: 3,966 exact comparisons, using actual ambient dimension "
        "seven for collar curvature jets, with interpolation, determinant "
        "and all-plane square identities.",
        "- Parameters: explicit sufficient finite smallness bounds and their "
        "rational implications, with analytic premises stated separately.",
        "- Strict intervals: six groups using 200-bit outward-rounded "
        "Sage/MPFI/MPFR intervals, including 224 rational cells covering "
        "[1/2,4]. These certify scalar inequalities, not the entire curvature "
        "function of a closed sphere. Unbounded tails use stated analytic bounds.",
        "- The concrete interval witness is **northern-only**. Its A0=1 "
        "is not asserted to satisfy southern connection requirements for "
        "any n; it is not a closed-sphere metric.", "",
        "## Exact certificate categories", "",
        "| Certificate kind | Count | Independent replay meaning |",
        "| --- | ---: | --- |",
    ]
    meanings = {
        "expression_identity": "Expand both restricted arithmetic expressions "
                               "afresh over exact rational numbers.",
        "polynomial_identity": "Compare encoded sparse coefficient objects.",
        "nonnegative_coefficients": "Check coefficients with required "
                                    "nonnegative-orthant assumptions.",
    }
    for kind, number in sorted(kinds.items()):
        lines.append(f"| {kind} | {number} | {meanings.get(kind,'See checker.')} |")
    lines += [
        "", "Only entries explicitly listed under replayable are accepted "
        "by the small checker. It does not recompute transcendental intervals "
        "or reconstruct thousands of tensor entries. Rerun the corresponding "
        "Sage modules for those operations.", "",
        "## Every explicitly non-machine-verified group", "",
        "The following claims and evidence are reproduced from the actual "
        "summary rather than replaced by a generic warning.", "",
    ]
    for item in unverified:
        evidence = item.get("evidence", "")
        if not isinstance(evidence, str):
            evidence = json.dumps(evidence, sort_keys=True)
        lines += [f"### {item['module']} : {item['id']}", "",
                  "**Claim.** " + item["claim"], "",
                  "**Recorded evidence/scope.** " + evidence, ""]
    lines += [
        "## Trust boundary", "",
        "The Sage computation trusts its input geometric model, implementation, "
        "Sage arithmetic/interval dependencies and runtime. Independent replay "
        "reduces reliance on Sage for exported polynomial identities; it still "
        "trusts the small checker, Python exact arithmetic and fidelity of "
        "the encoded claims. Neither path automatically proves faithful "
        "manuscript translation or every global premise.", "",
        "The human audits distinguish a checked external-theorem interface, "
        "a locally reconstructed identity, and an analytic argument. No "
        "detected error in a scoped review is not proof that no error exists. "
        "Smooth classification, equivariant bundles and quotients, uniform "
        "analysis and gluing hypotheses remain visible proof dependencies.", "",
        "## Public interpretation and reproduction", "",
        "Appropriate description: **a version-bound, executed and reproducible "
        "computational verification companion, with exact algebraic "
        "certificates, rigorous scalar intervals and explicitly stated "
        "non-formalized dependencies**. It is not a Lean proof, blanket "
        "approval of the paper, or an end-to-end machine certificate for "
        "strictly positive curvature on all 28 smooth types.", "",
        "- Full Sage run: follow README.md and reproduce.sh.",
        "- Ordinary Python replay:", "",
        "    python3 -I verify_certificates.py certificates", "",
        "- Separate-runtime evidence: reproduction/independent-replay.json "
        "and the corresponding stdout.log and stderr.log files.",
        "- Reference execution: reproduction/reference-run/summary.json and logs/.",
        "- Mathematical scope and claim mapping: docs/PROOF_SCOPE.md.",
        "- Scoped audits: checks/topology_audit.md, checks/connection_audit.md, "
        "checks/north_audit.md and checks/gluing_audit.md.",
        "- Publication wording: docs/PUBLICATION_SCOPE.md.", "",
    ]
    (ROOT / "VERIFICATION_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({
        "report": "VERIFICATION_REPORT.md",
        "copied_certificate_files": len(copied),
        "independent_replay_status": status,
        "independent_replay_checked": total,
        "runtime_version": runtime["version"],
        "sage_discoverable": runtime["sage_discoverable"],
        "reference_counts": counts,
        "main_theorem_machine_status": "NOT_FULLY_FORMALIZED_OR_MACHINE_CERTIFIED",
    }, indent=2))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--python", default=sys.executable,
                        help="A Python interpreter without importable Sage")
    args = parser.parse_args()
    return prepare(args.python)


if __name__ == "__main__":
    raise SystemExit(main())
