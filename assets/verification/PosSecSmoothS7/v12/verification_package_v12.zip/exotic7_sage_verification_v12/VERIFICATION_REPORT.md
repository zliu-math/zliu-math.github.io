# Verification report — v12

## Outcome

The archived SageMath 10.9 run reports **80 PASS groups, 0 FAIL groups, and 7 explicitly UNVERIFIED-by-computation dependency groups**.

**48 exact rational polynomial certificates** were accepted by a separate standard-library-only Python interpreter (CPython 3.12.14). The runtime probe found no importable Sage installation. All **33** right-side-plus-one expression mutations were rejected in the reference run. The connection module also includes a separately identified wrong-sign negative control.

**The complete geometric existence theorem is not formally machine certified by this package.** PASS concerns implemented checks and their assumptions, not every global argument in the paper. UNVERIFIED means not established by these finite computational tests; it does not mean that the mathematical statement is false.

## Exact input and execution

- Manuscript: paper/submitted.tex, the submitted v12_clean.tex.
- Source SHA-256:

    ea27de068cd78871211d0a1ac102e76b65c7bd1f033267fb24a2c5f8dc423f9e

- Revised-source SHA-256: ea27de068cd78871211d0a1ac102e76b65c7bd1f033267fb24a2c5f8dc423f9e
- The submitted and revised sources are byte-identical in this release.
- Reference started: 2026-09-25T13:34:42.305207+00:00
- Reference finished: 2026-09-25T13:34:58.716926+00:00
- Reference elapsed time: 16.4113 seconds (machine-dependent, not a correctness criterion).
- Reference Python: 3.13.15 | packaged by conda-forge | (main, Sep  2 2026, 21:53:23) [Clang 21.1.8 ]
- Reference platform: macOS-26.3-arm64-arm-64bit-Mach-O
- The release helper checked archived hashes of all executed modules and recorded support files before preparing this report.

## Module counts

These are check groups, not independent theorems or tensor-component counts.

| Module | PASS | FAIL | UNVERIFIED | Reference seconds |
| --- | ---: | ---: | ---: | ---: |
| source_binding | 3 | 0 | 0 | 0.025 |
| topology | 11 | 0 | 0 | 4.202 |
| connection | 26 | 0 | 1 | 4.1813 |
| north | 12 | 0 | 1 | 3.8021 |
| gluing | 11 | 0 | 4 | 1.4611 |
| parameter_logic | 5 | 0 | 1 | 1.3225 |
| interval_bounds | 6 | 0 | 0 | 1.3156 |
| document | 4 | 0 | 0 | 0.0266 |
| replay and mutation controls | 2 | 0 | 0 | in total |

## What was computed

- Source binding: exact hash, frozen labeled-display inventory, and preservation of the supplied manuscript.
- Quaternionic topology algebra: generic quaternion identities, marked-transition algebra, action norm bound and label bookkeeping. The smooth classification remains an external mathematical input.
- Connection geometry: independent Koszul/curvature reconstruction for a seven-dimensional base and three-dimensional fibre, including 5,176 tensor/connection comparisons, quaternion sign checks, decomposability relations, mixed contractions and absorption identities.
- Northern geometry: complete ten-dimensional doubly warped source reconstruction, with 45 diagonal and 1,980 off-diagonal bivector matrix entries, plus graph, profile and boundary identities.
- Gluing: 3,966 exact comparisons, using actual ambient dimension seven for collar curvature jets, with interpolation, determinant and all-plane square identities.
- Parameters: explicit sufficient finite smallness bounds and their rational implications, with analytic premises stated separately.
- Strict intervals: six groups using 200-bit outward-rounded Sage/MPFI/MPFR intervals, including 224 rational cells covering [1/2,4]. These certify scalar inequalities, not the entire curvature function of a closed sphere. Unbounded tails use stated analytic bounds.
- The concrete interval witness is **northern-only**. Its A0=1 is not asserted to satisfy southern connection requirements for any n; it is not a closed-sphere metric.

## Exact certificate categories

| Certificate kind | Count | Independent replay meaning |
| --- | ---: | --- |
| expression_identity | 33 | Expand both restricted arithmetic expressions afresh over exact rational numbers. |
| nonnegative_coefficients | 3 | Check coefficients with required nonnegative-orthant assumptions. |
| polynomial_identity | 12 | Compare encoded sparse coefficient objects. |

Only entries explicitly listed under replayable are accepted by the small checker. It does not recompute transcendental intervals or reconstruct thousands of tensor entries. Rerun the corresponding Sage modules for those operations.

## Every explicitly non-machine-verified group

The following claims and evidence are reproduced from the actual summary rather than replaced by a generic warning.

### connection : south.external_geometry

**Claim.** Global marked-disk identification, action freeness, and O'Neill descent are external to this symbolic module

**Recorded evidence/scope.** This module certifies the displayed local algebra; it does not replace bundle topology or a proof of the Riemannian-submersion theorem.

### north : N13

**Claim.** Global analytic/topological hypotheses needed to turn the exact north certificates into a complete filling and gluing theorem.

**Recorded evidence/scope.** Not formalized: smooth eta and inverse profile, global quotient marking, earlier southern theorem and the subsequent gluing theorem. These are distinguished from the exact checks above.

### gluing : gluing.analytic.uniformity

**Claim.** Uniform C_X^j estimates, positivity for sufficiently small tau, and compact minima on all plane bundles.

**Recorded evidence/scope.** UNVERIFIED by finite algebra. Analytic audit finds the supplied argument valid for fixed smooth families on compact X with Delta>=2*b_* h and positive input sectional curvature; these hypotheses are not established by this module.

### gluing : gluing.analytic.smoothing

**Claim.** Common tensor convolution and localized smoothing preserve positive sectional curvature.

**Recorded evidence/scope.** UNVERIFIED by finite algebra. Analytic audit finds no gap: C1 matching removes singular measures; R=L(D2G)+Q(G,DG); C1 convergence controls Q; nonnegative convolution preserves the decomposable-bivector cone; C2 convergence controls the fixed smooth cutoff annuli. Bounds depend on tau after tau is fixed.

### gluing : gluing.application.input_metrics

**Claim.** The particular disk metrics satisfy the global positive sectional-curvature and strictly positive boundary-jump hypotheses.

**Recorded evidence/scope.** Outside this module: no finite Appendix B identity verifies the earlier geometric construction or its premises.

### gluing : gluing.external.quantitative_bound

**Claim.** Section 6 obtains K>min(c_S,c_N)/2 from Reiser-Wraith Corollary B.

**Recorded evidence/scope.** Primary source arXiv:2308.06996v2, Theorem A(i) and Corollary B, was read on 2026-09-25: k=1 is sectional curvature and the lower threshold may be any real kappa. This is a checked external theorem interface, not a machine proof. Appendix B alone does not assert this exact half-min constant.

### parameter_logic : P06

**Claim.** The concrete n-dependent curvature suprema and smooth cutoff derivative bounds are finite, and all interval/exponential monotonicity hypotheses apply

**Recorded evidence/scope.** This is established by the smooth compact geometric construction and elementary analysis; no finite CAS assertion formalizes these global statements.

## Trust boundary

The Sage computation trusts its input geometric model, implementation, Sage arithmetic/interval dependencies and runtime. Independent replay reduces reliance on Sage for exported polynomial identities; it still trusts the small checker, Python exact arithmetic and fidelity of the encoded claims. Neither path automatically proves faithful manuscript translation or every global premise.

The human audits distinguish a checked external-theorem interface, a locally reconstructed identity, and an analytic argument. No detected error in a scoped review is not proof that no error exists. Smooth classification, equivariant bundles and quotients, uniform analysis and gluing hypotheses remain visible proof dependencies.

## Public interpretation and reproduction

Appropriate description: **a version-bound, executed and reproducible computational verification companion, with exact algebraic certificates, rigorous scalar intervals and explicitly stated non-formalized dependencies**. It is not a Lean proof, blanket approval of the paper, or an end-to-end machine certificate for strictly positive curvature on all 28 smooth types.

- Full Sage run: follow README.md and reproduce.sh.
- Ordinary Python replay:

    python3 -I verify_certificates.py certificates

- Separate-runtime evidence: reproduction/independent-replay.json and the corresponding stdout.log and stderr.log files.
- Reference execution: reproduction/reference-run/summary.json and logs/.
- Mathematical scope and claim mapping: docs/PROOF_SCOPE.md.
- Scoped audits: checks/topology_audit.md, checks/connection_audit.md, checks/north_audit.md and checks/gluing_audit.md.
- Publication wording: docs/PUBLICATION_SCOPE.md.
