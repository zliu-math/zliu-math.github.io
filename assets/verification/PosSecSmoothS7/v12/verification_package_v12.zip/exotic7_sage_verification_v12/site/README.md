# Positive Curvature — Open Verification website

This is a self-contained bilingual static website for the v12 verification
release. It does not require a frontend framework, a package installation,
external fonts, remote assets, analytics or a build service.

The site reports computational evidence. It does **not** describe the
all-28 smooth-existence theorem as machine-proven. A missing or unreadable
release record produces an explicit warning, not invented check counts.

## Files and data provenance

- `index.html`: semantic page structure and an original two-cap vector
  schematic. The drawing is expressly not a computed curvature plot.
- `styles.css`: light responsive design, keyboard focus states and
  reduced-motion support.
- `app.js`: English/Chinese interface, check filters, exact evidence
  disclosure, download links and copyable reproduction commands.
- `data/release.json`: generated from the actual archived reference run.
- `build_release.mjs`: small Node.js data-generation utility. It reads
  `../reproduction/reference-run/summary.json`, its environment record and
  the submitted manuscript. It verifies count consistency and matching
  source hashes before writing `data/release.json`.

Check identifiers, claims and evidence are preserved verbatim from the
machine-readable run. The explanatory interface is bilingual; it does not
silently translate or strengthen those recorded mathematical claims.
The generated data also preserves all additional check fields, including
exact residual counts where supplied.

To regenerate site data after an intentional new reference run, execute
from the verification package root:

```sh
node site/build_release.mjs
```

This command does not run Sage, alter the manuscript, or reclassify any
check result. It only makes a website-readable projection of the actual
run. It must not be used as a substitute for a fresh verification run
when the mathematical source or checking code changes.

## Local preview

Run a static server from this directory, then open the displayed address:

```sh
python3 -m http.server 8765 --bind 127.0.0.1
```

Open `http://127.0.0.1:8765/`.
Directly opening `index.html` with a `file://` address may prevent the
browser from fetching `data/release.json`. If JavaScript is disabled,
the page provides a link to the raw release record.

Previewing the site does not run the mathematical verification. The three
reproduction modes shown on the page match the package's actual CLI:

```sh
# From the extracted verification package directory, with Sage available:
sh reproduce.sh

# Alternatively, create the documented environment first:
conda env create -f environment.yml
conda activate exotic7-verification
sh reproduce.sh

# Independent rational-certificate replay only; no Sage required:
python3 verify_certificates.py certificates
```

If Sage is not on the shell path, the package also accepts an explicitly
selected Sage-enabled Python:

```sh
SAGE_PYTHON=/path/to/sage/environment/bin/python sh reproduce.sh
```

Do not replace these commands with `sage -python` or `sage file.py`:
those invocation styles do not match the tested installed environment
and runner behavior.

## Downloads to supply before publication

The release record links to the following relative paths. The final
packaging/deployment step must copy the actual artifacts there:

```text
downloads/verification_package_v12.zip
downloads/verification_report_en.pdf
downloads/verification_report_zh.pdf
downloads/v12_clean.tex
downloads/results.json
downloads/exact_certificates.zip
```

`results.json` should be the original archived `summary.json`, not a
manually edited dashboard summary. `exact_certificates.zip` should
contain the actual exported certificate data. Polynomial certificates
and directed-rounding interval records have different replay scopes,
as explained on the site and in the reports.

The website ZIP download should not recursively contain another copy of
itself. Construct the verification archive first, then copy that finished
archive into the separately prepared deployment directory, or exclude
`site/downloads/` while packaging the verification release.

## GitHub Pages deployment

This site is designed to work at:

```text
https://zliu-math.github.io/projects/PosSecSmoothS7/
```

All runtime assets, data and downloads use relative URLs. Preserve the
trailing slash on the canonical project URL, or configure the host to
redirect to it, so `./data/release.json` resolves inside the project.

For a plain static deployment, place `index.html`, `styles.css`, `app.js`,
`data/` and the populated `downloads/` directory at the project path.
The generator and this README need not be served publicly.

For an existing Jekyll site, use a project-specific layout or a static
page arrangement which does not wrap this complete HTML document in a
second `<html>`/`<body>` structure. Do not add unreviewed theme assets or
rewrite the relative URLs to root-relative URLs. The supplied HTML has
no Jekyll/Liquid templates and no dependency on a particular theme.

Publishing changes a public website. These files alone do not prove that
publication occurred; check the actual deployment result and verify the
live URL after authorized publication.

## Pre-publication checks

1. Regenerate release data from the final archived run.
2. Confirm the site record contains the same complete check ledger and
   source hash as the package, including all UNVERIFIED items.
3. Populate and open every download link.
4. Inspect desktop and narrow-screen layouts in both languages.
5. Exercise PASS/UNVERIFIED/FAIL filters, search, evidence disclosure,
   module links, all three command tabs and copy buttons.
6. Check the missing-data state and keyboard navigation.
7. Verify the public page makes no claim of end-to-end machine proof.

Language preference is stored locally in the browser when storage is
available. No browsing or verification data is transmitted to a service.
