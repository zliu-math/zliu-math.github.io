/** Build public website data only from the actual archived reference run.
 * Run from any directory: node path/to/site/build_release.mjs
 * No metric, certificate, source file or execution log is modified.
 */
import {readFile, writeFile, mkdir} from "node:fs/promises";
import {fileURLToPath} from "node:url";
import path from "node:path";
import {createHash} from "node:crypto";

const site = path.dirname(fileURLToPath(import.meta.url));
const packageRoot = path.dirname(site);
const summaryPath = path.join(packageRoot, "reproduction/reference-run/summary.json");
const environmentPath = path.join(packageRoot, "reproduction/reference-run/environment.json");
const summaryBytes = await readFile(summaryPath);
const environmentBytes = await readFile(environmentPath);
const summary = JSON.parse(summaryBytes);
const environment = JSON.parse(environmentBytes);
const hash = bytes => createHash("sha256").update(bytes).digest("hex");
const checks = summary.checks;
if (!Array.isArray(checks) || checks.some(c => !c.id || !c.module || !c.claim || !["PASS", "UNVERIFIED", "FAIL"].includes(c.status))) throw new Error("Invalid check ledger");
const counts = {PASS: 0, UNVERIFIED: 0, FAIL: 0};
for (const check of checks) counts[check.status]++;
for (const status of Object.keys(counts)) {
  if (counts[status] !== (summary.counts[status] || 0)) throw new Error(`Check ledger disagrees with summary: ${status}`);
}
const manuscriptBytes = await readFile(path.join(packageRoot, "paper/submitted.tex"));
if (hash(manuscriptBytes) !== summary.source_sha256 || summary.source_sha256 !== environment.source_sha256) throw new Error("Source fingerprints disagree");
const replay = checks.find(c => c.id === "independent_exact_replay");
const negative = checks.find(c => c.id === "incorrect_certificates_rejected");
if (!Number.isInteger(replay?.evidence?.checked)) throw new Error("Exact replay count is missing");
if (!Number.isInteger(negative?.evidence?.mutations_tested)) throw new Error("Negative-control record is missing");

const descriptions = {
  source_binding: "Exact source fingerprint and version-bound labeled-formula correspondence.",
  topology: "Quaternion identities, equivariant-coordinate algebra, and smooth-type label bookkeeping.",
  connection: "Principal-frame Koszul reconstruction, full mixed curvature blocks, decomposable planes, southern radius and gauge identities.",
  north: "Warped curvature identities, horizontal-graph bounds, northern parameter estimates and boundary matching.",
  gluing: "Collar curvature and smoothing identities, with analytic and external theorem dependencies explicitly separated.",
  parameter_logic: "Exact parameter and loss-budget implications for fixed geometric data.",
  interval_bounds: "Directed-rounding scalar interval enclosures and a northern-only parameter witness, not interval proof of the complete theorem.",
  document: "Source labels, cross-references, citation keys and preservation of the supplied theorem statements.",
  certificate_replay: "Independent rational-certificate replay and deliberate-error rejection."
};
const moduleNames = [...new Set(checks.map(c => c.module))];
const modules = moduleNames.map(name => {
  const selected = checks.filter(c => c.module === name);
  return {name, pass: selected.filter(c => c.status === "PASS").length,
    unverified: selected.filter(c => c.status === "UNVERIFIED").length,
    fail: selected.filter(c => c.status === "FAIL").length,
    description: descriptions[name] || "See the module's exact checks and stated premises.",
    limitations: summary.limitations[name] || []};
});
const release = {
  schema_version: 1,
  version: "v12",
  date: summary.finished_utc.slice(0, 10),
  source_sha256: summary.source_sha256,
  sage_version: environment.sage_version,
  counts,
  exact_certificates: replay.evidence.checked,
  negative_controls: {
    status: negative.status,
    tested: negative.evidence.mutations_tested,
    rejected: negative.evidence.mutations_tested - negative.evidence.accepted_mutations.length,
    all_rejected: negative.evidence.all_rejected,
    scope: negative.claim
  },
  checks,
  downloads: {
    package: "./downloads/verification_package_v12.zip",
    en_report: "./downloads/verification_report_en.pdf",
    zh_report: "./downloads/verification_report_zh.pdf",
    source: "./downloads/v12_clean.tex",
    results: "./downloads/results.json",
    certificates: "./downloads/exact_certificates.zip"
  },
  modules,
  main_theorem_machine_status: summary.main_theorem_machine_status,
  computation_status: summary.computation_status,
  meaning_of_pass: summary.meaning_of_pass,
  arithmetic: environment.arithmetic,
  provenance: {
    summary: "reproduction/reference-run/summary.json",
    summary_sha256: hash(summaryBytes),
    environment: "reproduction/reference-run/environment.json",
    environment_sha256: hash(environmentBytes),
    started_utc: summary.started_utc,
    finished_utc: summary.finished_utc,
    elapsed_seconds: summary.elapsed_seconds
  }
};
await mkdir(path.join(site, "data"), {recursive: true});
await writeFile(path.join(site, "data/release.json"), JSON.stringify(release, null, 2) + "\n");
process.stdout.write(JSON.stringify({checks: checks.length, counts, certificates: release.exact_certificates,
  negative_controls: release.negative_controls, modules: modules.length,
  output: "site/data/release.json"}, null, 2) + "\n");
