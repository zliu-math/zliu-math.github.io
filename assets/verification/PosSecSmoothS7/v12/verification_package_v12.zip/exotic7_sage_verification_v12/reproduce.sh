#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ -z "${DOT_SAGE:-}" ]; then
    DOT_SAGE="$PWD/.sage-runtime"
    export DOT_SAGE
fi
mkdir -p "$DOT_SAGE"
if [ -n "${SAGE_PYTHON:-}" ]; then
    exec "$SAGE_PYTHON" verify_all.py "$@"
fi
if command -v sage >/dev/null 2>&1; then
    if [ "$#" -ne 0 ]; then
        printf '%s\n' 'For optional arguments, set SAGE_PYTHON to the Sage environment Python.' >&2
        exit 2
    fi
    exec sage -c "import runpy; runpy.run_path('verify_all.py', run_name='__main__')"
fi
printf '%s\n' 'Activate the SageMath environment, or set SAGE_PYTHON=/path/to/sage/environment/bin/python.' >&2
exit 2
