"""Locate labeled display formulas. Hash binding is not semantic proof."""
import hashlib
import re


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def inventory(text):
    displays = re.compile(r"\\begin\{(equation\*?|align\*?|gather\*?)\}(.*?)\\end\{\1\}", re.S)
    result = []
    for match in displays.finditer(text):
        body = match.group(0)
        labels = re.findall(r"\\label\{([^}]+)\}", body)
        if not labels:
            continue
        # Comments and whitespace only are normalized; no mathematical symbols
        # are rewritten or silently identified with one another.
        normalized = re.sub(r"\s+", "", re.sub(r"(?<!\\)%[^\n]*", "", body))
        result.append({"labels": labels, "line": text[:match.start()].count("\n")+1,
                       "environment": match.group(1), "latex": body,
                       "normalized_sha256": sha256(normalized.encode())})
    return result
