#!/usr/bin/env python3
"""Capture the installed Sage conda package versions without network access."""
import json
from pathlib import Path
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    conda = Path(sys.prefix).parent.parent / "bin/conda"
    if not conda.is_file():
        raise SystemExit("This optional capture utility expects a Sage conda environment.")
    destination=root/"reproduction"
    destination.mkdir(exist_ok=True)
    for arguments, name in [(["--explicit"],"conda-osx-arm64-explicit.txt"),
                            (["--json"],"conda-packages.json")]:
        result=subprocess.run([str(conda),"list","--prefix",sys.prefix,*arguments],
                              capture_output=True,text=True,check=True)
        output=result.stdout
        if name.endswith(".json"):
            output=json.dumps(json.loads(output),indent=2,sort_keys=True)+"\n"
        (destination/name).write_text(output)
        print(name)


if __name__=="__main__":
    main()
