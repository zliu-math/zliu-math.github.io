# v12 / SageMath verification companion

This release is bound to the unchanged user-supplied `v12_clean.tex`, not the
previous manuscript. Start with `VERIFICATION_REPORT.md`, then the English or
Chinese PDF in `reports/` for a detailed mathematical reading guide.

**A successful run means the implemented computations passed. It is not a
complete machine proof of the all-28 smooth-existence theorem.** Human analysis,
global geometry and external theorems remain explicit dependencies.

The executed v12 reference run reports **80 PASS, 0 FAIL, 7 UNVERIFIED** check
groups. The independent checker accepts **48** supported rational certificates
and rejects all **33** deliberately altered expression certificates. These
counts refer to the results in `reproduction/reference-run/summary.json`; they
are not percentages of the main theorem or counts of newly proved theorems.

## What is included

- Exact Sage derivations of the connection tensor, quaternion algebra,
  full ten-dimensional northern metric and seven-dimensional collar curvature.
- Genuine 200-bit directed-rounding scalar interval computations, with exact
  rational domain and enclosure endpoints.
- Independently replayable rational polynomial certificates and a Python
  standard-library checker; the latter does **not** re-prove transcendental
  interval enclosures.
- Raw execution logs, result JSON, source/code hashes, an environment lock,
  negative controls and fresh-extraction reproduction records.
- The unmodified manuscript, 80 inventoried labeled display blocks containing
  92 labels, scoped mathematical
  audits, the nine-statement proof map and bilingual explanatory reports.
- A responsive bilingual public website in `site/`; publication status is
  recorded separately and is never inferred from a passing computation.

## Run the entire verification

From an activated SageMath 10.9 environment:

```sh
sh reproduce.sh
```

Or supply the Python executable from an existing Sage environment:

```sh
SAGE_PYTHON=/path/to/sage/environment/bin/python sh reproduce.sh
```

The run writes `local-run/` and a local Sage cache; it does not overwrite the
reference evidence in `reproduction/reference-run/`. Do not use Python `-O`;
the runner rejects optimized execution because assertions are intentional.

For the Sage CLI, this also explicitly executes the program rather than merely
loading it:

```sh
sage -c "import runpy; runpy.run_path('verify_all.py', run_name='__main__')"
```

The installed 10.9 CLI does not accept the old `sage -python` spelling.

## Independent rational certificate replay

```sh
python3 verify_certificates.py certificates
```

Only Python's standard library is needed. The checker parses restricted
arithmetic expressions with `Fraction` coefficients; it never executes the
certificate strings as code. The complete Sage run additionally rejects
deliberately corrupted identities. Interval enclosures are recomputed by the
Sage module, not by this rational checker.

## Environment and interpretation

`environment.yml` specifies the supported Sage/Python family. The explicit
conda lock in `reproduction/` records the actual Apple Silicon builds. It is
platform-specific; use the YAML on other platforms. Download availability is
external to this archive, and no fresh environment installation is claimed.

`PASS` means the named computational assertion passed. `FAIL` is a detected
failure or execution error. `UNVERIFIED` denotes noncomputational dependencies,
not a hidden green check and not automatically a manuscript error. The output
always records the complete main theorem as
`NOT_FULLY_FORMALIZED_OR_MACHINE_CERTIFIED`.

The 28 residues are classification labels, not 28 numerical metric tests.
Source hashing binds a version; it does not prove mathematics. The northern
scalar witness does not assert southern admissibility or a closed sphere metric.
The 224 interval cells cover the scalar range `[1/2,4]`; analytic tail estimates
are separate. The 80 display blocks and the 80 PASS groups are different,
coincidentally equal counting units.

## Review and maintenance

Read `docs/CLAIM_MAP.md`, `docs/PROOF_SCOPE.md` and the module audit notes.
`docs/reviewed_formula_contract.json` records the separately reviewed source.
Do not regenerate it merely to make an unreviewed new version pass. Future
edits require formula-to-code correspondence review, then a new run and release.

The code license is in `LICENSE-CODE`. Manuscript rights remain with its
authors. This release contains no Lean formalization, external certification,
journal acceptance claim or automated proof of every analytic step.
