#!/usr/bin/env python3
"""Render explanatory reports; never changes verification results.

Stage 1: Python with matplotlib: --math
Stage 2: Python with reportlab and Pillow: --pdf
Fonts may be overridden with --latin-font-dir and --cjk-font-dir.
"""
import argparse
import hashlib
import json
from pathlib import Path
from xml.sax.saxutils import escape

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ASSETS = HERE / 'equations'

def inputs():
    s = json.loads((ROOT/'reproduction/reference-run/summary.json').read_text())
    e = json.loads((ROOT/'reproduction/reference-run/environment.json').read_text())
    byid = {c['id']: c for c in s['checks']}
    vals = {'PASS_COUNT':s['counts']['PASS'], 'UNVERIFIED_COUNT':s['counts']['UNVERIFIED'],
            'CERT_COUNT':byid['independent_exact_replay']['evidence']['checked'],
            'MUTATION_COUNT':byid['incorrect_certificates_rejected']['evidence']['mutations_tested'],
            'SOURCE_SHA':s['source_sha256'], 'SAGE_VERSION':e['sage_version']}
    contents = []
    for lang in ['en','zh']:
        raw = (HERE/f'content_{lang}.json').read_text()
        for k,v in vals.items(): raw=raw.replace('{{'+k+'}}',str(v))
        if '{{' in raw: raise ValueError('Unfilled placeholder')
        contents.append(json.loads(raw))
    return s,e,vals,contents

def eqpath(eq): return ASSETS/(hashlib.sha256(eq.encode()).hexdigest()[:20]+'.png')

def render_math(contents):
    from matplotlib.mathtext import math_to_image
    from matplotlib.font_manager import FontProperties
    ASSETS.mkdir(exist_ok=True)
    equations=sorted({q for c in contents for ch in c['chapters'] for q in ch['equations']})
    for eq in equations:
        math_to_image('$'+eq+'$',str(eqpath(eq)),prop=FontProperties(size=17),dpi=300,format='png',color='#183450')
    print(json.dumps({'equations_rendered':len(equations)}))

def build_pdfs(contents,s,e,vals,args):
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib import colors
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_LEFT
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Image,Table,TableStyle,KeepInFrame
    from PIL import Image as PILImage
    for name,file in [('Sans','DejaVuSans.ttf'),('SansBold','DejaVuSans-Bold.ttf')]:
        pdfmetrics.registerFont(TTFont(name,str(Path(args.latin_font_dir)/file)))
    for name,file in [('CJK','STHeiti Light.ttc'),('CJKBold','STHeiti Medium.ttc')]:
        pdfmetrics.registerFont(TTFont(name,str(Path(args.cjk_font_dir)/file),subfontIndex=0))
    navy=colors.HexColor('#183450'); blue=colors.HexColor('#245EEA'); grey=colors.HexColor('#5E6D7E')
    pale=colors.HexColor('#EEF3FA'); amber=colors.HexColor('#865A14')
    W,H=595.28,841.89; width=W-104
    def normalized(x):
        return str(x).replace('\u2011','-').replace('\u2013','-').replace('\u2014',' - ')
    formula=json.loads((ROOT/'docs/reviewed_formula_contract.json').read_text())['labeled_displays']
    for c in contents:
        zh=c['language']=='zh'; font='CJK' if zh else 'Sans'; bold='CJKBold' if zh else 'SansBold'
        styles={
          'body':ParagraphStyle('body',fontName=font,fontSize=11.1 if zh else 10.5,leading=18 if zh else 16.2,textColor=navy,spaceAfter=12,wordWrap='CJK' if zh else None),
          'title':ParagraphStyle('title',fontName=bold,fontSize=22,leading=30,textColor=navy,spaceAfter=18),
          'kicker':ParagraphStyle('kicker',fontName='SansBold',fontSize=9,leading=13,textColor=blue,spaceAfter=10),
          'small':ParagraphStyle('small',fontName=font,fontSize=8,leading=12,textColor=grey,wordWrap='CJK' if zh else None),
          'cell':ParagraphStyle('cell',fontName='Sans',fontSize=8,leading=11.5,textColor=navy,splitLongWords=True),
          'id':ParagraphStyle('id',fontName='SansBold',fontSize=7.8,leading=11,textColor=blue,splitLongWords=True),
          'bullet':ParagraphStyle('bullet',fontName=font,fontSize=9.5,leading=15,textColor=navy,leftIndent=12,firstLineIndent=-9,spaceAfter=8,wordWrap='CJK' if zh else None),
        }
        def p(t,key='body'): return Paragraph(escape(normalized(t)),styles[key])
        def eq(q):
            path=eqpath(q)
            with PILImage.open(path) as im: iw,ih=im.size
            scale=min(0.24,(width-24)/iw,52/ih)
            return Image(str(path),width=iw*scale,height=ih*scale,hAlign='CENTER')
        def footer(canvas,doc):
            canvas.setStrokeColor(pale);canvas.line(52,51,W-52,51)
            canvas.setFont('Sans',8);canvas.setFillColor(grey)
            canvas.drawString(52,35,'PosSecSmoothS7 / v12 / Computational verification companion')
            canvas.drawRightString(W-52,35,str(doc.page))
            if doc.page>1:
                canvas.setFont('SansBold',8);canvas.setFillColor(blue)
                canvas.drawString(52,H-33,'OPEN VERIFICATION  /  25 SEPTEMBER 2026')
        doc=SimpleDocTemplate(str(HERE/f'verification_report_{c["language"]}.pdf'),pagesize=(W,H),
            rightMargin=52,leftMargin=52,topMargin=62,bottomMargin=67,
            title=c['title'],author='PosSecSmoothS7 verification companion',subject='Scope and reproduction of the v12 SageMath computations')
        story=[Spacer(1,35),p('RESEARCH COMPUTATION / EXPLANATORY REPORT','kicker'),p(c['title'],'title'),p(c['subtitle']),Spacer(1,20)]
        rows=[[p(str(vals['PASS_COUNT'])+' PASS','title'),p(str(vals['CERT_COUNT'])+' EXACT','title'),p(str(vals['UNVERIFIED_COUNT'])+' HUMAN','title')],
              [p('检查组通过' if zh else 'Passing check groups','small'),p('可重放精确证书' if zh else 'Replayable certificates','small'),p('未机器证明的依赖组' if zh else 'Unformalized dependency groups','small')]]
        t=Table(rows,colWidths=[width/3]*3);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),pale),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,0),16),('BOTTOMPADDING',(0,-1),(-1,-1),16)]));story += [t,Spacer(1,24)]
        story += [p('实际运行：SageMath '+e['sage_version']+'；零失败。' if zh else 'Actually executed in SageMath '+e['sage_version']+'. Zero failed check groups.'),
          p('这不是对全部二十八类存在性主定理的完整机器认证。计算证据、人类数学审查与外部定理依赖在本报告中分别列出。' if zh else 'This is not complete machine certification of the all-28 existence theorem. Computational evidence, scoped mathematical review and external dependencies are separated throughout.'),
          Spacer(1,22),p('SOURCE SHA-256','kicker'),p(s['source_sha256'],'small'),Spacer(1,12),p('Submitted source preserved byte-for-byte. Release date: 2026-09-25.','small'),PageBreak()]
        story += [p('阅读导航' if zh else 'Reading guide','title'),p('正文按证明依赖顺序展开；附录保留全部检查索引与公式定位。' if zh else 'Read the mathematical chain in order, then use the appendices to locate every check and source formula.')]
        toc=[]
        for i,ch in enumerate(c['chapters']): toc.append([p(ch['id'],'id'),p(ch['title'],'small'),p(str(i+3),'small')])
        t=Table(toc,colWidths=[30,width-60,30]);t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),5),('LINEBELOW',(0,0),(-1,-1),.3,pale)]));story += [t,Spacer(1,14),p('Appendix A: every check group. Appendix B: source formula inventory. Full evidence is in the accompanying JSON files.','small'),PageBreak()]
        for ch in c['chapters']:
            inner=[p('CHAPTER '+ch['id'],'kicker'),p(ch['title'],'title')]
            for para in ch['paragraphs']: inner.append(p(para))
            inner.append(Spacer(1,5))
            for q in ch['equations']: inner += [eq(q),Spacer(1,14)]
            for b in ch['bullets']: inner.append(p('- '+b,'bullet'))
            inner += [Spacer(1,8),p('References' if zh else 'Source and evidence','kicker')]
            for ref in ch['references']: inner.append(p(ref,'small'))
            story += [KeepInFrame(width,700,inner,mode='shrink'),PageBreak()]
        checks=s['checks']
        for offset in range(0,len(checks),8):
            story += [p('APPENDIX A / '+str(offset+1)+'-'+str(min(offset+8,len(checks))),'kicker'),p('完整检查索引' if zh else 'Complete check register','title')]
            if offset==0: story.append(p('以下主张保留程序中的英文原文；证据仅作摘要，完整对象见 summary.json。PASS 不证明其上游几何假设。' if zh else 'Claims are quoted from the executed checks. Evidence below is abbreviated; summary.json retains complete objects. PASS does not establish upstream geometric assumptions.','small'))
            for check in checks[offset:offset+8]:
                ev=check.get('evidence','')
                if not isinstance(ev,str): ev=json.dumps(ev,ensure_ascii=False,sort_keys=True)
                if len(ev)>205:ev=ev[:202]+'...'
                story += [Spacer(1,10),p(check['id']+' / '+check['status']+' / '+check['module'],'id'),p(check['claim'],'cell'),p(ev,'small')]
            story.append(PageBreak())
        for offset in range(0,len(formula),24):
            story += [p('APPENDIX B / '+str(offset+1)+'-'+str(min(offset+24,len(formula))),'kicker'),p('源公式定位表' if zh else 'Source formula inventory','title'),p('80 个显示公式块、92 个标签。哈希绑定版本，不验证公式语义。行号指 package/paper/submitted.tex。' if zh else '80 display blocks, 92 labels. Hashes bind a version, not formula semantics. Line numbers refer to paper/submitted.tex.','small'),Spacer(1,14)]
            rows=[[p('Label(s)','id'),p('Line','id'),p('SHA-256 prefix','id')]]
            for f in formula[offset:offset+24]:rows.append([p(', '.join(f['labels']),'cell'),p(str(f['line']),'cell'),p(f['normalized_sha256'][:14],'cell')])
            t=Table(rows,colWidths=[width-145,40,105],repeatRows=1);t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),pale),('BOTTOMPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),.3,pale)]));story.append(t)
            if offset+24<len(formula):story.append(PageBreak())
        doc.build(story,onFirstPage=footer,onLaterPages=footer)
        print(str(HERE/f'verification_report_{c["language"]}.pdf'))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--math',action='store_true');a.add_argument('--pdf',action='store_true')
    a.add_argument('--latin-font-dir',default='/Users/gaopin/miniforge3/envs/sage/lib/python3.13/site-packages/matplotlib/mpl-data/fonts/ttf')
    a.add_argument('--cjk-font-dir',default='/System/Library/Fonts')
    args=a.parse_args();summary,environment,values,content=inputs()
    if args.math: render_math(content)
    if args.pdf: build_pdfs(content,summary,environment,values,args)
