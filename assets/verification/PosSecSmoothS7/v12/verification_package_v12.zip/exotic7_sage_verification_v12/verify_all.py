#!/usr/bin/env python3
"""Run all Sage checks, write exact evidence, and report the actual scope.

Run from a Sage-enabled Python, or use reproduce.sh. A successful return means
all implemented computational checks and certificate replays passed. Analytic
and literature dependencies remain separately visible; success does not mean
the complete geometric theorem has been formally proved by a proof assistant.
"""
import argparse
import copy
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback


ROOT = Path(__file__).resolve().parent
MODULES = ("source_binding", "topology", "connection", "north", "gluing", "parameter_logic", "interval_bounds", "document")


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")


def execute(out):
    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    out.mkdir(parents=True, exist_ok=True)
    certificates = out / "certificates"
    logs = out / "logs"
    certificates.mkdir(exist_ok=True)
    logs.mkdir(exist_ok=True)
    from sage.env import SAGE_VERSION
    if sys.flags.optimize:
        raise RuntimeError("Run without Python -O: this package deliberately uses executable assertions")
    environment = {
        "sage_version": SAGE_VERSION, "python_version": sys.version,
        "platform": platform.platform(), "machine": platform.machine(),
        "arithmetic": "Exact QQ polynomial/Laurent/fraction rings; symbolic differentiation/limits; separately labeled rigorous real-interval scalar enclosures; no floating-point curvature sampling",
        "source_sha256": sha256(ROOT / "paper/submitted.tex"),
        "revised_sha256": sha256(ROOT / "paper/revised.tex"),
        "started_utc": started,
        "checked_code_sha256": {str(p.relative_to(ROOT)): sha256(p)
                                for p in sorted(ROOT.glob("checks/*.py"))},
        "support_code_sha256": {p: sha256(ROOT / p) for p in
                               ("verify_all.py", "verify_certificates.py", "certificate_format.py", "formula_contract.py", "docs/reviewed_formula_contract.json")}}
    write_json(out / "environment.json", environment)
    all_checks, runs, limitations = [], [], {}
    for name in MODULES:
        print(f"Running {name} ...", flush=True)
        start = time.monotonic()
        command = [sys.executable, str(ROOT / "checks" / f"{name}.py")]
        process = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                                 env=dict(os.environ), check=False)
        (logs / f"{name}.stdout.log").write_text(process.stdout)
        (logs / f"{name}.stderr.log").write_text(process.stderr)
        run = {"module": name, "returncode": process.returncode,
               "elapsed_seconds": round(time.monotonic()-start, 4)}
        try:
            if process.returncode:
                raise RuntimeError(f"Module exited {process.returncode}; see stderr log")
            result = json.loads(process.stdout)
            checks = result["checks"]
            if not checks:
                raise ValueError("Empty check list is not success")
            if any(c.get("status") not in ("PASS", "FAIL", "UNVERIFIED") for c in checks):
                raise ValueError("Invalid check status")
            all_checks.extend({"module": name, **c} for c in checks)
            write_json(certificates / f"{name}.json", result.get("certificates", {}))
            limitations[name] = result.get("limitations", [])
            run["counts"] = dict(Counter(c["status"] for c in checks))
        except Exception as exc:
            run["error"] = str(exc)
            all_checks.append({"module": name, "id": f"{name}.execution",
                               "status": "FAIL", "claim": "The check module runs and returns structured results",
                               "evidence": str(exc)})
        runs.append(run)
        print(f"  {name}: {run.get('counts', run.get('error'))}", flush=True)
    print("Replaying exact certificates without importing Sage ...", flush=True)
    replay = subprocess.run([sys.executable, str(ROOT / "verify_certificates.py"), str(certificates)],
                            cwd=ROOT, capture_output=True, text=True, check=False)
    (logs / "certificate_replay.stdout.log").write_text(replay.stdout)
    (logs / "certificate_replay.stderr.log").write_text(replay.stderr)
    try:
        replay_result = json.loads(replay.stdout.strip().splitlines()[-1])
    except Exception:
        replay_result = {"error": "Could not parse replay summary"}
    all_checks.append({"module": "certificate_replay", "id": "independent_exact_replay",
                       "status": "PASS" if replay.returncode == 0 else "FAIL",
                       "claim": "The standard-library-only checker accepts all exported supported certificates",
                       "evidence": replay_result})
    # A real negative control: perturb every unexpanded identity by +1.
    # This runs entirely in memory and cannot alter the published evidence.
    from verify_certificates import verify_one
    mutation_count = 0
    mutations_rejected = True
    accepted_mutations = []
    for path in sorted(certificates.glob("*.json")):
        for item in json.loads(path.read_text()).get("replayable", []):
            if item["kind"] != "expression_identity":
                continue
            changed = copy.deepcopy(item)
            changed["rhs"] = "(" + changed["rhs"] + ")+1"
            mutation_count += 1
            rejected = not verify_one(changed)
            mutations_rejected = mutations_rejected and rejected
            if not rejected:
                accepted_mutations.append(changed.get("id", "unnamed"))
    all_checks.append({"module": "certificate_replay", "id": "incorrect_certificates_rejected",
                       "status": "PASS" if mutation_count and mutations_rejected else "FAIL",
                       "claim": "Adding 1 to the right side of each unexpanded identity is detected",
                       "evidence": {"mutations_tested": mutation_count, "all_rejected": mutations_rejected,
                                    "accepted_mutations": accepted_mutations}})
    counts = dict(Counter(c["status"] for c in all_checks))
    failed = [c["id"] for c in all_checks if c["status"] == "FAIL"]
    summary = {
        "schema_version": 1, "computation_status": "PASS" if not failed else "FAIL",
        "main_theorem_machine_status": "NOT_FULLY_FORMALIZED_OR_MACHINE_CERTIFIED",
        "meaning_of_pass": "All implemented checks, rigorous scalar interval enclosures and exact certificate replays passed; this is not a certificate for the complete all-28 smooth-existence theorem.",
        "counts": counts, "failed_checks": failed, "checks": all_checks,
        "limitations": limitations, "runs": runs,
        "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": round(time.monotonic()-clock, 4),
        "source_sha256": environment["source_sha256"],
        "revised_sha256": environment["revised_sha256"]}
    write_json(out / "summary.json", summary)
    lines = ["# Reproduction result", "",
             f"Computational checks: **{summary['computation_status']}**.", "",
             "Complete geometric theorem: **not formally machine certified by this package**.", "",
             f"SageMath {SAGE_VERSION}; started {started}.", "",
             "| Check | Status | Claim |", "|---|---|---|"]
    for c in all_checks:
        claim = c["claim"].replace("|", "\\|").replace("\n", " ")
        lines.append(f"| {c['id']} | {c['status']} | {claim} |")
    lines += ["", "UNVERIFIED denotes a claim not established by the finite computational test; see docs/PROOF_SCOPE.md for its human/external proof route."]
    (out / "RESULTS.md").write_text("\n".join(lines)+"\n")
    print(json.dumps({"computation_status": summary["computation_status"],
                      "counts": counts, "main_theorem_machine_status": summary["main_theorem_machine_status"],
                      "elapsed_seconds": summary["elapsed_seconds"]}), flush=True)
    return 1 if failed else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=str(ROOT / "local-run"),
                        help="Output directory; defaults to local-run, leaving reference results intact")
    args = parser.parse_args()
    try:
        return execute(Path(args.output).resolve())
    except Exception:
        traceback.print_exc()
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
