"""Maintenance tool: record a manuscript only after a new correspondence review.

This is deliberately not called by reproduce.sh. Replacing this contract after
an unreviewed source edit would defeat its purpose.
"""
import argparse
import json
from pathlib import Path
from formula_contract import inventory, sha256

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--acknowledge-completed-review', action='store_true',required=True)
args = parser.parse_args()
raw = (ROOT/'paper/submitted.tex').read_bytes()
result = {'version':'v12','source_sha256':sha256(raw),
          'review_scope':'Full supplied v12 read; source correspondence, local geometric arguments and reported external interfaces reviewed. No end-to-end formal verification is claimed.',
          'labeled_displays':inventory(raw.decode('utf-8'))}
(ROOT/'docs/reviewed_formula_contract.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'sha256':result['source_sha256'],'display_blocks':len(result['labeled_displays'])}))
