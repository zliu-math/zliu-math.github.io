# What the exact certificates prove

## Two layers of evidence

The executable Sage modules reconstruct the larger algebraic calculations from
their defining data. They export compact witnesses for selected identities and
inequality kernels. `verify_certificates.py` replays those witnesses using only
Python's standard library and exact rational arithmetic.

The replayable collection is not a second implementation of every curvature
calculation. For example, the 5,176 connection component comparisons are
reproduced by the Sage script; the small certificate collection contains the
contractions and scalar kernels supporting their use. This distinction is part
of the public verification scope, not a hidden implementation detail.

The recorded v12 collection contains 48 replayable certificates: 33 unexpanded
expression identities, 12 sparse polynomial identities, and three
nonnegative-coefficient certificates. All 33 expression identities are also
subjected to the `+1` corruption test and rejected after alteration.

| Producing module | Replayable certificates |
| --- | ---: |
| Quaternion topology | 2 |
| Connection and southern filling | 22 |
| Northern filling and boundary | 12 |
| Gluing | 9 |
| Common-parameter logic | 2 |
| Scalar intervals: separate polynomial identity only | 1 |
| Source binding and document consistency | 0 |
| **Total** | **48** |

## Certificate representations

Each module's JSON has a `replayable` array. The supported formats are:

1. **Expression identity.** Variables and two unexpanded arithmetic expressions
   are provided. The checker parses a restricted syntax and expands each side
   as a dictionary of monomials with `Fraction` coefficients. The result must
   have exactly equal rational coefficients. Variable denominators are cleared
   by the generating script; only nonzero rational denominators are admitted.
2. **Sparse polynomial identity.** Each side is already represented by rational
   coefficient/exponent data. The checker normalizes and compares them. This
   checks the exported arrays, not their derivation from the manuscript; the
   generating Sage code is required for that correspondence.
3. **Nonnegative-coefficient polynomial.** Every coefficient is nonnegative,
   and each variable has an explicit nonnegative-domain assumption. The checker
   confirms both. This certifies nonnegativity on that orthant, not positivity
   on an unstated geometric domain.

Every rational is stored exactly. There is no tolerance parameter and no use of
floating-point arithmetic in certificate acceptance. The reader should still
inspect the code and its source correspondence. This is not a foundational
proof kernel, and it does not remove the trust placed in the implementation.

The full run also changes the right-hand side of each unexpanded identity by
adding 1 and requires rejection. These deliberately false certificates exist
only in memory. This catches a checker that unconditionally returns success;
it is a useful negative control, not a proof of software infallibility.

## Quaternionic quotient and horizontal graph

The exact quaternion algebra verifies associativity, multiplicativity of the
norm, and invariance of the quotient coordinate under the star action:

\[
 (qu)^{-1}(qxq^{-1})(qu)=u^{-1}xu.
\]

For the infinitesimal conjugation map K at x=(p,w), one obtains

\[
 K^*K=4\bigl((|p|^2+|\operatorname{Im}w|^2)I
                 -pp^T-\operatorname{Im}(w)\operatorname{Im}(w)^T\bigr).
\]

On the unit sphere the remainder in the bound |Kv|^2 <= 4|v|^2 is the explicit
sum of squares

\[
 4\bigl((\operatorname{Re}w)^2|v|^2
              +\langle p,v\rangle^2+\langle\operatorname{Im}w,v\rangle^2\bigr).
\]

The generic graph T=-(F/r)K^* yields the cometric
F^{-2}I+r^{-2}KK^*. These checks include rank-degenerate orbits: no inverse of
K is taken. The external attaching-map classification is not a polynomial
identity and is explicitly outside this certificate's scope.

## Full connection curvature

The connection script derives Levi--Civita coefficients by Koszul's formula,
then differentiates them and computes the curvature. Its seven horizontal and
three vertical indices match the source dimension. Equivariance derivatives
and the right-action bracket signs are checked separately using quaternion
vector fields.

For a decomposable two-vector xi=(X+U) wedge (Y+V), write h,m,k for the norms
of its horizontal, mixed, and vertical parts. Exact expansion gives

\[
 |\xi|^2=h^2+m^2+k^2.
\]

The Plücker identity supplies the contraction with coefficient -3/2. The loss
terms are bounded using declared tensor norms, Cauchy--Schwarz, and identities
of the form

\[
 a x^2-a bxy+\frac{a b^2}{4}y^2
       =a\left(x-\frac b2y\right)^2\ge0,\qquad a>0.
\]

After the stated geometric and smallness hypotheses, the assigned budgets leave

\[
 \mathcal K(\xi)\ge\frac\kappa2h^2
             +\frac{\varepsilon\Lambda}{8}m^2
             +\frac1{8\varepsilon}k^2.
\]

The machine checks algebra and budgets, not the existence of an arbitrary
geometric object satisfying those hypotheses. The manuscript's southern
construction is the separate proposed source of those objects.

## Northern metric

The five independently reconstructed doubly warped curvature coefficients are

\[
 -F''/F,\quad -r''/r,\quad (1-F'^2)/F^2,\quad
 (1-r'^2)/r^2,\quad -F'r'/(Fr).
\]

The v12 metric-two-jet computation uses all six angular and three fibre
coordinates plus the radial coordinate. It checks the complete 45-by-45
curvature operator: 45 diagonal matches and 1,980 exact off-diagonal zeros.

One global scalar inequality reduces to the exact factorization

\[
 t^4-4t+3=(t-1)^2(t^2+2t+3)\ge0\quad(t>0).
\]

The use of this polynomial after a hyperbolic-sine series lower bound still
requires the analytic series argument. The profile's finite Taylor jet is
checked, but its global smoothness uses the inverse-function construction.

At the boundary, with 0<=b<=4 an eigenvalue of KK^*, the exact sum of the two
shape eigenvalues is

\[
 \frac{r_a^2(\mu_N-\mu_S)}{r_a^2+F_a^2b}
 \ge\frac{r_a^2(\mu_N-\mu_S)}{r_a^2+4F_a^2}>0.
\]

The cancellation of the fibre terms is checked with the paper's two outward
normal conventions. Equality of the full boundary source metrics under the
specified gauge is an additional geometric input.

## Gluing

The Hermite formula is checked against all endpoint values and first normal
derivatives. For arbitrary symmetric 2-by-2 matrices P,Q, the certificate is

\[
 \det((1-\lambda)P+\lambda Q)
 =(1-\lambda)\det P+\lambda\det Q
       -\lambda(1-\lambda)\det(P-Q).
\]

Together with the Gauss sign, this gives a nonnegative tangential correction
when the boundary jump is positive definite. The coordinate-jet calculation
also checks the radial and Codazzi blocks, and a Young square controls every
mixed angle. Formal Taylor remainder *orders* are verified algebraically;
uniform smooth estimates and the smoothing limit remain analytic arguments.
The v12 collar calculation uses the actual ambient dimension seven and records
3,966 exact residual comparisons, including the complete coordinate, radial,
Gauss, and Codazzi block checks. These are separate from its nine independently
replayable certificates; adding the counts would obscure their different roles.

## A nonempty common epsilon interval

`parameter_logic.json` lists twelve positive upper bounds after fixing all
geometric data. Their minimum is a symbolic witness for an admissible interval.
The basic exact slack identities are

\[
 A(1+x)-Ax=A,\qquad
 \varepsilon-\varepsilon^3
     =\varepsilon(1-\varepsilon)(1+\varepsilon).
\]

Thus an upper bound A/[B(1+x)] supplies positive reserve in A-B epsilon x for
A,B>0 and x>=0. Adding 1 to the denominators avoids division by zero when a
curvature supremum vanishes. No numerical values of the clutching-dependent
suprema are asserted or required. Their finiteness is supplied by the smooth
compact construction, not by sampling.

## Directed-rounding intervals are a separate evidence layer

The new scalar module encloses R(x)=2 sinh(x^2/2)/x^3 at 200-bit precision on
224 adjacent rational intervals covering [1/2,4]. Its lower interval endpoints
are all greater than 1/2. Every endpoint is exported as an exact rational, not
as a rounded decimal. The two tails use the explicitly stated analytic series
bound; no finite sample is substituted for an infinite domain.

These transcendental enclosures are NOT among the polynomial expressions that
the standard-library checker can reproduce. Rerun `interval_bounds.py` under
Sage to recompute them. The interval module's sole independently replayable
polynomial certificate is explicitly separated under its `replayable` key.

## Reuse after editing the paper

Changing the paper does not automatically change these independently written
formulas. Re-run the checks, compare source hashes, and review every affected
formula-to-code correspondence. A previous PASS is not a certificate for an
unreviewed revision. `document.py` detects label/reference problems and compares
the nine statement environments between the two included copies. It is not a
cross-release mathematical change detector, and editing both copies identically
would not be exposed by that comparison alone. `source_binding.py` additionally
checks the full-source digest against the separately reviewed contract and
compares its inventoried labeled displays. Updating that contract requires a new
review, not merely a regenerated hash; even a correct hash proves identity rather
than correctness of the translation or mathematics.
