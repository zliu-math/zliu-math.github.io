#!/usr/bin/env python3
"""Recheck exported rational polynomial certificates using Python only.

This intentionally does not import Sage or evaluate mathematical source strings.
Its conclusion covers the encoded identities/nonnegativity statements, not the
translation from the manuscript, curvature geometry, or the main theorem.
"""
import argparse
import ast
from fractions import Fraction
import json
from pathlib import Path
import sys


def read_polynomial(data, dimension):
    if not isinstance(data, dict) or not isinstance(data.get("terms"), list):
        raise ValueError("Missing polynomial term list")
    answer = {}
    for term in data["terms"]:
        powers = term["powers"]
        if (len(powers) != dimension or
                any(type(k) is not int or k < 0 for k in powers)):
            raise ValueError("Invalid monomial exponents")
        coefficient = Fraction(term["coefficient"])
        key = tuple(powers)
        answer[key] = answer.get(key, Fraction(0)) + coefficient
    return {k: v for k, v in answer.items() if v}


def expression_polynomial(text, variables):
    """Expand a restricted arithmetic AST; never execute certificate code."""
    n = len(variables)
    zero = (0,) * n

    def clean(p):
        return {m: c for m, c in p.items() if c}

    def add(p, q, sign=1):
        out = dict(p)
        for m, c in q.items():
            out[m] = out.get(m, Fraction(0)) + sign * c
        return clean(out)

    def multiply(p, q):
        out = {}
        for m, c in p.items():
            for k, d in q.items():
                mk = tuple(a + b for a, b in zip(m, k))
                out[mk] = out.get(mk, Fraction(0)) + c * d
        return clean(out)

    def visit(node):
        if isinstance(node, ast.Constant) and type(node.value) is int:
            return clean({zero: Fraction(node.value)})
        if isinstance(node, ast.Name) and node.id in variables:
            powers = [0] * n
            powers[variables.index(node.id)] = 1
            return {tuple(powers): Fraction(1)}
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            p = visit(node.operand)
            return p if isinstance(node.op, ast.UAdd) else {m: -c for m, c in p.items()}
        if isinstance(node, ast.BinOp):
            p = visit(node.left)
            if isinstance(node.op, ast.Pow):
                if not isinstance(node.right, ast.Constant) or type(node.right.value) is not int:
                    raise ValueError("Power must be an integer literal")
                exponent = node.right.value
                if not 0 <= exponent <= 100:
                    raise ValueError("Power out of range")
                out = {zero: Fraction(1)}
                for _ in range(exponent):
                    out = multiply(out, p)
                return out
            q = visit(node.right)
            if isinstance(node.op, ast.Add):
                return add(p, q)
            if isinstance(node.op, ast.Sub):
                return add(p, q, -1)
            if isinstance(node.op, ast.Mult):
                return multiply(p, q)
            if isinstance(node.op, ast.Div):
                if set(q) != {zero} or q[zero] == 0:
                    raise ValueError("Only nonzero rational constant denominators are allowed")
                return {m: c / q[zero] for m, c in p.items()}
        raise ValueError("Unsupported certificate expression")

    return visit(ast.parse(text, mode="eval").body)


def verify_one(item):
    variables = item["variables"]
    if not all(isinstance(v, str) for v in variables):
        raise ValueError("Invalid variable list")
    if len(variables) != len(set(variables)):
        raise ValueError("Duplicate variables")
    n = len(variables)
    if item["kind"] == "expression_identity":
        return expression_polynomial(item["lhs"], variables) == expression_polynomial(item["rhs"], variables)
    if item["kind"] == "polynomial_identity":
        return read_polynomial(item["lhs"], n) == read_polynomial(item["rhs"], n)
    if item["kind"] == "nonnegative_coefficients":
        # The domain is part of the claim; never silently invent assumptions.
        required = {f"{v} >= 0" for v in variables}
        if not required.issubset(set(item.get("domain", []))):
            raise ValueError("Nonnegative coefficient certificate lacks orthant assumptions")
        return all(c >= 0 for c in read_polynomial(item["polynomial"], n).values())
    raise ValueError(f"Unsupported certificate kind: {item['kind']}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", nargs="?", default="certificates")
    args = parser.parse_args()
    directory = Path(args.directory)
    total = 0
    failures = []
    for path in sorted(directory.glob("*.json")):
        document = json.loads(path.read_text())
        for item in document.get("replayable", []):
            total += 1
            try:
                ok = verify_one(item)
                detail = "exact rational coefficient comparison"
            except Exception as exc:
                ok, detail = False, str(exc)
            print(f"{'PASS' if ok else 'FAIL'} {path.name}:{item.get('id')} ({detail})")
            if not ok:
                failures.append(f"{path.name}:{item.get('id')}")
    if not total:
        print("FAIL: no replayable certificates found", file=sys.stderr)
        return 2
    print(json.dumps({"checked": total, "failures": failures,
                      "scope": "encoded rational polynomial claims only"}))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
